import { LightningElement, api,wire,track } from 'lwc';

import getPicklistOptions from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.getPicklistOptions';

import {
    loadStyle
} from 'lightning/platformResourceLoader';
import ASSETS from '@salesforce/resourceUrl/AGN_GCSP_Assets';
import ASSETS1 from '@salesforce/resourceUrl/AGN_CustomerPortal_LWC';

export default class Agn_gcsp_productInterestCmp extends LightningElement {  

   
    @api customertype;
    @api customersubtype;
    @api custtypeconfig;
    @api customergroup;
    @api countrycode;

    @track error;
    @track optionList

    renderedCallback() {
        loadStyle(this, ASSETS + '/assets/agn_gcsp_registration.css');
        loadStyle(this, ASSETS1 + '/css/style.css');   
        loadStyle(this, ASSETS1 + '/css/footer.css');     
    }
    connectedCallback() {

        this.getPicklistOptions();        
        console.log('inside connected customertype>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(this.customertype)); 
        console.log('inside connected customersubtype>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(this.customersubtype)); 
        console.log('inside connected custtypeconfig>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(this.custtypeconfig)); 
        console.log('inside connected customergroup>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(this.customergroup)); 
        console.log('inside connected countrycode>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(this.countrycode)); 
    }

    getPicklistOptions(){
        getPicklistOptions(
            {
                ObjectName : 'Allergan_Customer_Registration_AGN__c',
                fieldName : 'Product_Interest_AGN__c'
            }
        ).then(result => {
            console.log('result>>>>>>>>>>>>>>>>>>>>>>>'+result); 
            let options = result;
            var prodOptions = [];
            var optionMap = new Map();
            var custConfig = this.custtypeconfig;
            options.forEach(val=>{
                console.log('val>>>>>>>>>>>>>>>>>>>>>>>'+val.value); 
                console.log('label>>>>>>>>>>>>>>>>>>>>>>>'+val.label); 
                optionMap.set(val.value,val.label);
            });
            console.log('optionMap>>>>>>>>>>>>>>>>>>>>>>>'+optionMap); 
            if(custConfig && optionMap )
            {
                console.log('optionMap1>>>>>>>>>>>>>>>>>>>>>>>'); 
                custConfig.forEach(confg=>{
                    console.log('optionMap6>>>>>>>>>>>>>>>>>>>>>>>'+JSON.stringify(confg)); 
                    if(this.customertype && this.customersubtype && confg.Product_Interest_AGN__c && (confg.Category_AGN__c === this.customertype || confg.Category_Label_AGN__c === this.customertype)
                    && (confg.Sub_Category__c === this.customersubtype || confg.Sub_Category_Label_AGN__c === this.customersubtype)
                    && confg.Customer_Country_AGN__r.Name === this.countrycode)
                    {
                        console.log('optionMap2>>>>>>>>>>>>>>>>>>>>>>>'); 
                        var ops = confg.Product_Interest_AGN__c.split(';');
                        if(ops){
                            console.log('optionMap3>>>>>>>>>>>>>>>>>>>>>>>'); 
                            ops.forEach(op=>{
                                console.log('optionMap4>>>>>>>>>>>>>>>>>>>>>>>'); 
                                if(optionMap.has(op)){ 
                                    console.log('optionMap5>>>>>>>>>>>>>>>>>>>>>>>');
                                    prodOptions.push({label : optionMap.get(op) , value : op});
                                }
                            });
                        }
                    }
                });
            }
            console.log('prodOptions>>>>>'+prodOptions);
            this.optionList = prodOptions;
        }).catch(error =>
            {
                //console.log('error layout>>>>>>>>>>>>>>>>>>>' + JSON.stringify(error));
                //this.error = error;                
                //this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();

            });

    }

    getGCSPCustomSettings(registration , countryCode){
        getGCSPSettings({country : countryCode})
        .then(result => {
            if(result){
                console.log('Custom Settings Data Response :: ',result);
                let shiptoLimit = parseInt(result.Number_Of_ShipTo_Allowed_AGN__c);
                let shiptolen = this.getShiptoLength();
                if(shiptoLimit){
                    if(shiptolen <= shiptoLimit){
                        this.showNewShiptoButton = true;
                     }else{
                         this.showNewShiptoButton = false;
                     }
                     this.shiptoLimit = shiptoLimit;
                }
                
                this.getConfigurations(registration, countryCode);
            }else{
                this.showLoader = false;
                this.hidemaindiv = false;
                this.setErrorMessage('' , 'Unknown Error');
            }
        })
        .catch(error => {
            console.log('Error in GCSP Settings Callout :: ',error);
            this.setErrorMessage(error , '');
            this.showLoader = false;
            this.hidemaindiv = false;
        });
    }

    handleChk(event){

        const eventParemeters = event.detail;
        console.log('Event captured>>>'+eventParemeters.selectedVal);
        var chkSelectedEvent = new CustomEvent('chkboxselected', {
            detail: {
                selectedVal: eventParemeters.selectedVal,
                isSelected : eventParemeters.isSelected
            }
        });
        this.dispatchEvent(chkSelectedEvent);

    }
    

}