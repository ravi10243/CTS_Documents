import { api, LightningElement } from 'lwc';

// Apex Method to fetch Account details
import getAccountDetail from '@salesforce/apex/AGN_Account_Hierarchy_Helper.getAccountDetail';

// List of fields to be displayed in the datatable
const COLUMNS = [
    { label: 'Name', fieldName: 'Name', type: 'string' },
    { label: 'Account Sub Type', fieldName: 'Type_AGN__c', type: 'string' },
    { label: 'Status', fieldName: 'Status_AGN__c', type: 'string' }
];

export default class AccountHierarchyAccountDetail extends LightningElement {

    // Public variable to accept the Id of the account for which information is to be displayed
    @api accountId;
    // Reactive variable to accept data from imperative apex call, and display data
    record;
    // List of columns to be displayed in datatble
    columns = COLUMNS;
    // This variable set to false when component is inserted and to true when apex promise is completed
    // Controls spinner at component load  
    rendered;

    // Action to be executed on insertion of the component
    connectedCallback() {
        this.rendered = false;
    }

    // Action to be performed once all the public attributes are set by parent components.
    renderedCallback() {

        // Check to prevent recursive imperative call on render
        if(!this.rendered) {
            // Making imperative apex call to get account details and setting to record variable
            getAccountDetail({ accountId: this.accountId })
                .then(result => {
                    this.record =  result;
                })
                .catch(error => {
                    this.wireError =  error.body.message;
                })
                // Switching off loader spinner and allow display of data 
                .finally(() => {
                    this.rendered = true;
                });
        }
    }
}