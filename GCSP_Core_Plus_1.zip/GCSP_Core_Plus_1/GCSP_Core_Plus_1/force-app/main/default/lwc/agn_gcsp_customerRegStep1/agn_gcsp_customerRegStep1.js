import { LightningElement,track,api,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';


import getLayout from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.getLayout';
import fetchCountryList from '@salesforce/apex/AGN_GCSP_PortalCustomerRegUtils.fetchCountryList';
import isDuplicateUser from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.isDuplicateUser';
import createAccount from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.createAccount';
import createContact from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.createContact';
import createCommunityUser from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.createCommunityUser';
import createNewCustomerRegistration from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.createNewCustomerRegistration';
import createOktaUserSendLink from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller_FD.createOktaUserSendLink';
import getAddressDetails from '@salesforce/apex/AGN_GCSP_PortalCustomerRegUtils.fetchAddress';//
import getCustomerGroup from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.getCustomerGroup';

import AGN_OAM_Body_Country from '@salesforce/label/c.AGN_OAM_Body_Country';
import AGN_OAM_Body_CustomerType from '@salesforce/label/c.AGN_OAM_Body_CustomerType';
import AGN_OAM_Body_SubType from '@salesforce/label/c.AGN_OAM_Body_SubType';
import AGN_CP_AMIPractice from '@salesforce/label/c.AGN_CP_AMIPractice';
import AGN_CP_AboutPractice from '@salesforce/label/c.AGN_CP_AboutPractice';
import AGN_CP_Contact from '@salesforce/label/c.AGN_CP_Contact';
import AGN_CP_Practice_Address from '@salesforce/label/c.AGN_CP_Practice_Address';
import AGN_CP_Please_Provide_Address from '@salesforce/label/c.AGN_CP_Please_Provide_Address';
import AGN_CP_Please_Confirm from '@salesforce/label/c.AGN_CP_Please_Confirm';
import AGN_CP_Privacy_Policy from '@salesforce/label/c.AGN_CP_Privacy_Policy';
import AGN_CP_Agree_Terms from '@salesforce/label/c.AGN_CP_Agree_Terms';
import AGN_CP_FORMSUBMIT from '@salesforce/label/c.AGN_CP_FormSubmit';
import AGN_OAM_Body_CommunicationContact from '@salesforce/label/c.AGN_OAM_Body_CommunicationContact';
import AGN_OAM_Body_Address from '@salesforce/label/c.AGN_OAM_Body_Address';



export default class Agn_gcsp_customerRegStep1 extends NavigationMixin(LightningElement)  {
    
    //@api box_img_step1_active = ASSETS + '/assets/Images/Registration/box_img_step1_active.png';
    @api country;
    @api language;
    @api customertype;
    @api customersubtype;
    @api customertypeconfig;    
    @api picklistcountryoptions;
    @api countryCode;
   // @api customerTypeConfig;

    @track picklistCustomerTypeOptions;
    @track addressDetails;
    @track picklistSubTypeOptions;
    @track customerTypeConfig;
    @track showStep1;
    @track stepNo;
    @track basicInformationFields;
    @track practiceAddressFields;
    @track contactFields;
    @track showLoader;
    @track isCompleted;
    @track hidemaindiv;
    @track custTypeConfig;
    @track showtest=false;
    @track account;
    @track contact;   
    @track disableSubmitBtn = true;
    @track layoutMetadataMaster;
    @track customerGroup;
    @track productOfInterest = true;

    @track termsURL;
    @track cpEnabledCountries;
    @track displayMainTemplate = false;
    @track record;
    @track isAMIUser = false;
    @api source = null;

    label = {
        AGN_OAM_Body_Country,
        AGN_OAM_Body_CustomerType,
        AGN_OAM_Body_SubType,
        AGN_CP_AMIPractice,
        AGN_CP_AboutPractice,
        AGN_CP_Practice_Address,
        AGN_CP_Please_Provide_Address,        
        AGN_CP_Please_Confirm,
        AGN_CP_Privacy_Policy,
        AGN_CP_Agree_Terms,
        AGN_CP_Contact,        
        AGN_CP_FORMSUBMIT,
        AGN_OAM_Body_CommunicationContact,
        AGN_OAM_Body_Address
    }
    connectedCallback() {
        console.log('inside connected callback of reg 1>>>>>>>>>>>>>>>>>>>>>>>');  
        this.custTypeConfig = this.customertypeconfig;
        this.getLayoutForInternational(this.country, this.customertype, this.customersubtype, this.customertypeconfig); 
        
        //String countryCode, String customerType , String customerSubType 
    }
    @api
    refreshRegForm(custType,custSubType)
    {
        console.log('inside refreshRegForm of reg 1>>>>>');   
        //console.log('testVal>>>',testVal);
        ///console.log('testVal2>>>',testVal2);
        this.showStep1 = false;
        this.customertype = custType;
        this.customersubtype = custSubType;
        //this.customertype = ctype;
        //this.customersubtype = subtype;
        //this.customertypeconfig = typeconfig;
        //this.picklistcountryoptions = countryOption;       
        this.getLayoutForInternational(this.country, this.customertype, this.customersubtype, this.customertypeconfig);  
    }
/*
    @wire(fetchCountryList, { countryCode: '$countryCode' }) countryConfig({ error, data }) {
        if (data) {
            console.log('Header Data*******', data);
            this.picklistCountryOptions = data[0];
            var customerTypeConfig = data[1];
            this.customerTypeConfig = customerTypeConfig;
            console.log('0customerTypeConfig', customerTypeConfig);
            console.log('eeecustomerTypeConfig',  this.customerTypeConfig);
            this.populateCustomerCategoryDropDown(this.countryCode, this.customerTypeConfig);
        } else if (error) {
            // eslint-disable-next-line no-console
            console.log('error on header component>>>>>>>', error);
        }
    }
    */
    getLayoutForInternational(countryCode, customerType, customerSubType, customerTypeConfig) {
       // console.log('customerTypeConfig>>:',customerTypeConfig);

        //console.log('getLayoutForInternational>>>>>>>>>>>>>>>', countryCode, customerType, customerSubType, customerTypeConfig);
        console.log('getLayoutForInternational>>>>>>>>>>>>>>>');
        if (countryCode === 'IT') {
            getLayout({ country: countryCode, stepNo: '1' })
                .then(result => {
                    console.log('result>>>>>>>>>>>>>>>>>>>', result);
                    this.setLayoutFields(result);
                    this.layoutMetadataMaster = result;
                    this.getCustomerGroupJs(this.country,this.customertype, this.customersubtype);
                })
                .catch(error => {
                    console.log('error>>>>>>>>>>>>>>>>>>>', error);
                    this.error = error;
                });
        } else {
            getLayout({
                country: countryCode, stepNo: '1',
                customerType: customerType, customerSubType: customerSubType,
                custTypeConfig: customerTypeConfig
            })
                .then(result => {
                    console.log('result of getLayout()Non-IT>>>', result);
                    this.setLayoutFields(result);
                    this.getCustomerGroupJs(this.country,this.customertype, this.customersubtype);
                    this.layoutMetadataMaster = result;
                })
                .catch(error => {
                    console.log('get layout error>>>>>>>>>>>>>>>>>>>', error);
                    this.error = error;
                });
        }

    }

    getCustomerGroupJs(countryCode, customerType, customerSubType) {            
        getCustomerGroup({
                 country: countryCode, 
                 customerType: customerType, 
                 customerSubType: customerSubType,                 
             })
                 .then(result => { 
                     this.customerGroup = result;
                     console.log('getCustomerGroup>>>>>>>>>>>>>>>>>>>',  this.customerGroup);
                 })
                 .catch(error => {
                     console.log('getCustomerGroup error>>>>>>>>>>>>>>>>>>>', error);
                     this.error = error;
                 });
     }

    setLayoutFields(data) {
        var settings = [];
        var settingsMap = data;
        var basicInformationFields = [];
        var practiceAddressFields = [];
        var contactFields = [];
        //console.log('settingsMap>>>>>>>>>>>>>>>>>>', settingsMap);
        for (var key in settingsMap) {
            if (key === 'Basic information') {
                basicInformationFields = settingsMap[key];
            } else if (key === 'Address') {
                practiceAddressFields = settingsMap[key];
            } else if (key === 'Communication Contact') {
                contactFields = settingsMap[key];
            }
        }
        this.basicInformationFields = basicInformationFields;
        this.practiceAddressFields = practiceAddressFields;
        if(this.isAMIUser){
            let amiToAdContactFields = [];
            contactFields.forEach(function (field) {
                if (field.Field_Name_AGN__c !== 'Email_AGN__c') {
                    amiToAdContactFields.push(field);
                }
            });
            this.contactFields = amiToAdContactFields;
        }else{
            this.contactFields = contactFields;
        }

        //console.log('basicInformationFields>>>>>>>>>>>>>>>>>>', basicInformationFields);
        //console.log('practiceAddressFields>>>>>>>>>>>>>>>>>>', practiceAddressFields);
        //console.log('contactFields>>>>>>>>>>>>>>>>>>', contactFields);
        this.showStep1 = true;

    }
   
    getCountrySFCode(country) {
        var countryobj;
        this.picklistcountryoptions.forEach(function (currRow) {
            if (currRow.Alpha_2_Code_vod__c.toUpperCase() === country.toUpperCase()) {
                countryobj = { 'countrySFDCId': currRow.Id, 'countryName': currRow.AGN_Country_Name__c };
            }
        });
        return countryobj;
    }

    showToast(title, message) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: "error"
        });
        this.dispatchEvent(event);
    }

    showToastSticky(title, message) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: "error",
            mode: "sticky"
        });
        this.dispatchEvent(event);
    }

    checkboxHandler(event) {
        console.log('event.target.checked>>>>>>>>>>>>>', event.target.checked);
        let fieldname = event.target.name;
        let checked = event.target.checked;
        if (fieldname === 'termsncondns') {
            if (checked) {
                this.disableSubmitBtn = false;
            } else {
                this.disableSubmitBtn = true;
            }
        }
    }
    handleClick() {
        alert('submitted');
        if(this.isAMIUser){
            //this.handleAMIToADSubmit();
        }else{
            alert('inside handleclick>>>>>>>>>>>>>>>>>>>');
            this.showLoader = true;
            this.hidemaindiv = true;
            var allValid = true;
            var isFormatValid = true;
            var country = this.countryCode;
            let address = { 'sobjectType': 'Allergan_Customer_Address_AGN__c' };
            let registration = { 'sobjectType': 'Allergan_Customer_Registration_AGN__c' };
            registration.Customer_Category_AGN__c =  this.customertype;
            registration.Customer_Sub_Category_AGN__c =  this.customersubtype;
            registration.Country_Code_AGN__c = this.country;
            registration.SAP_Country_Code_AGN__c = this.country;
            console.log('country>>>>>>>>>>>>>>>>>>>>>>>>', country);
            var countrysfobj = this.getCountrySFCode(this.country);
            console.log('countrysfobj>>>>>>>>>>>>>>>>>>>>>>>>', countrysfobj);
            if (countrysfobj) {
                registration.Country_AGN__c = countrysfobj.countrySFDCId;
                address.Country_Lookup_AGN__c = countrysfobj.countrySFDCId;
            }
            var hasFormatIssues = false;
            this.template.querySelectorAll('c-agn_gcsp_generate-input-field').forEach(element => {
                console.log('field>>>>>>>>>>>>'+element.fieldname+'>>>>>>>value>>>>>>>>>>>>>>>>>>>>', element.getUserEnteredInput()+'>>>element.checkValidity()>>>>'+element.checkValidity());
                console.log('required>>>>>>>>>>>>>>',element.required);
                console.log('sobject>>>>>>>>>>>>>>>>>>>>', element.sobjectname);
                console.log('fieldname>>>>>>>>>>>>>>>>>>>>', element.fieldname);
                isFormatValid = element.isFormatValid();
                if (!isFormatValid) {
                    console.log('Format Error>>>>Setting Message>>>>');
                    element.setCustomErrorMessage(AGN_CP_FORMAT_INVALID);
                    hasFormatIssues = true;
                } else {
                    element.setCustomErrorMessage('');
                }
                if (element.checkValidity() && isFormatValid) {
                    //allValid = true;
                    if (element.getUserEnteredInput()) {
                        if (element.sobjectname === 'Allergan_Customer_Registration_AGN__c') {
                            registration[element.fieldname] = element.getUserEnteredInput();
                        } else if (element.sobjectname === 'Allergan_Customer_Address_AGN__c') {
                            address[element.fieldname] = element.getUserEnteredInput();
                        }
                    }

                } else {
                    allValid = false;
                }
                console.log('Is Format Valid>>>>>>>>', isFormatValid);
                console.log('Registration>>>>>>>>>>>>>>>', registration);
                console.log('Address>>>>>>>>>>>>>>>>>>>>', address);

            });
            if (allValid && !hasFormatIssues) {
                //alert('All form entries look valid. Ready to submit>>>>!');
                console.log('calling isduplicate user>>>>>>>>>>>>>>>');
                isDuplicateUser({ email: registration.Email_AGN__c, country: country })
                    .then(result => {
                        console.log('isDuplicateUser>>>>>>>>>', result);
                        if (result) {
                            //show error
                            this.showLoader = false;
                            this.showToast('Error', AGN_OAM_Apex_DuplicateEmail);
                            this.hidemaindiv = false;
                        } else {

                            this.invokeCreateAccount(address, registration, this.ountry);
                        }

                    })
                    .catch(error => {
                        console.log(error);
                        this.error = error;
                        this.showLoader = false;
                        this.hidemaindiv = false;
                        this.showToast('Error', error);
                    });


            } else {
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', AGN_CP_Invalid_Input_Error);
            }
        }
       
    }

    invokeCreateAccount(address, registration, country) {
        console.log('country>>>>>>>>>>>>>>>', country);
        console.log('address>>>>>>>>>>>>>>>', address);
        console.log('registration>>>>>>>>>>>>>>>', registration);
        createAccount({ customerAddress: address, customer: registration, country: this.country })
            .then(result => {
                if (result) {
                    this.account = result;
                    console.log('New Account Created>>>>>>>>>', result);
                    this.invokeCreateContact(address, registration, result, country);
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', 'Unknown Error ');
                }
            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    invokeCreateContact(address, registration, account, country) {
        console.log('inside invokeCreateContact>>>>>>>', address, registration, account, country);
        createContact({ customer: registration, acc: account, country: country })
            .then(result => {
                if (result) {
                    this.contact = result;
                    console.log('New Contact Created>>>>>>>>>', result);
                   // this.invokecreateCommunityUser(address, result, country, registration);
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', 'Unknown Error ');
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }

    invokecreateCommunityUser(address, customerContact, country, registration) {
        var userLocale = this.language;
        createCommunityUser({ customerContactId: customerContact.Id, countryCode: country, userLocale: userLocale })
            .then(result => {
                if (result) {
                    this.contact = result;
                    console.log('New Community User Created>>>>>>>>>', result);
                   // this.invokeCreateCustomerRegistration(address, registration, this.customerTypeConfig, customerContact, userLocale, country);
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', 'Unknown Error ');
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    invokeCreateCustomerRegistration(address, registration, configList, customerContact, userLocale, country) {

        console.log('**********New Customer Registration************');
        console.log('customerAddress>>>>>>>>>>>>>>>>', address);
        console.log('configList>>>>>>>>>>>>>>>>', configList);
        console.log('customerContact>>>>>>>>>>>>>>>>', customerContact);
        console.log('userLocale>>>>>>>>>>>>>>>>', userLocale);
        createNewCustomerRegistration({
            customer: registration, customerAddress: address,
            configList: configList, customerContact: customerContact, userLocale: userLocale
        })
            .then(result => {
                if (result) {
                    console.log('New Customer Registration Created>>>>>>>>>', result);
                    this.invokeCreateOktaUserSendLink(registration, customerContact, userLocale, country);

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', 'Unknown Error ');
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    invokeCreateOktaUserSendLink(registration, customerContact, userLocale, country) {

        console.log('**********New Okta User Creation************');
        console.log('registration>>>>>>>>>>>>>>>>', registration);
        console.log('customerContact>>>>>>>>>>>>>>>>', customerContact);
        console.log('userLocale>>>>>>>>>>>>>>>>', userLocale);
        console.log('country>>>>>>>>>>>>>>>>', country);
        createOktaUserSendLink({
            customer: registration, customerContact: customerContact,
            userLocale: userLocale, country: country
        })
            .then(result => {
                console.log('New Okta User Created>>>>>>>>>', result);
                switch (result) {
                    case 'SUCCESS':
                        break;
                    case 'FAILURE': this.showToast('Error', 'Unknown Error, please contact customer service team.');
                        break;
                    case 'DEPROVISIONED': this.showToast('Error', 'User exists in Okta as DEPROVISIONED/Inactive State, please contact customer service team.');
                        break;
                    default: this.showToast('Error', 'Unknown Error ');
                        break;
                }
                this.showLoader = false;
                this.hidemaindiv = false;
                this.isCompleted = true;
                this.hidemaindiv = false;

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    handleZipCodeChange(event){
        //alert(event.detail);
        var zipCode = event.detail;

        getAddressDetails({ countryCode: this.country, zipCode: zipCode })
        .then(result => {            
          this.addressDetails = result;
          this.template.querySelectorAll('c-agn_gcsp_generate-input-field').forEach(element => {           
            
            if(element.fieldname=='City_AGN__c')
            {
                element.setInputValue(this.addressDetails.cityName);
            }
            else if(element.fieldname=='Street_Name_AGN__c')
            {
                element.setInputValue(this.addressDetails.streetName);
            }
            else if(element.fieldname=='State_AGN__c')
            {
                console.log('state>>',this.addressDetails.stateName);
                element.setInputValue(this.addressDetails.stateName);
            }
             else if(element.fieldname=='Address_Line_3_AGN__c')
            {
                element.setInputValue(this.addressDetails.addressLine3);
            }
          });
        })
        .catch(error => {
           console.log('error');
        });
    }

    handleControllingFieldEvent(event) {
        const eventParemeters = event.detail;

        const controllingFieldSobjectName = eventParemeters.controllingFieldSobjectName;
        console.log("controllingFieldSobjectName -> " + controllingFieldSobjectName);
        const controllingFieldName = eventParemeters.controllingFieldName;
        console.log("controllingFieldName -> " + controllingFieldName);
        const controllingFieldSelectedValue = eventParemeters.controllingFieldSelectedValue;
        console.log("controllingFieldSelectedValue -> " + controllingFieldSelectedValue);

        let dependentFieldList = [];
        //console.log("layoutMetadataMaster -> " + JSON.stringify(this.layoutMetadataMaster));
        //finding dependent field list based upon event received with parameters
        //console.log("layoutMetadataMaster Keys -> " +  Object.keys(this.layoutMetadataMaster));
        var itr = 1;
        Object.keys(this.layoutMetadataMaster).forEach(key => {
            console.log('layoutMetadataMaster[key]>>'+JSON.stringify(this.layoutMetadataMaster[key]));
            let dependentField = this.layoutMetadataMaster[key].find(layout => {
                console.log('layout>>'+JSON.stringify(layout));
                if (layout.Controlling_Field_AGN__c == controllingFieldName
                    && layout.Controlling_Field_SObject_Name_AGN__c == controllingFieldSobjectName){  
                        console.log('itr>>'+itr);
                        itr++;  
                        dependentFieldList.push(layout);               
                    //return layout;
                   
                }
            }
            );
            /*if (dependentField) {
                dependentFieldList.push(dependentField);
            }*/
        });

        if (dependentFieldList.length > 0) {
            console.log('dependentFieldList>>>'+JSON.stringify(dependentFieldList));            
            dependentFieldList.forEach(field => {
                this.template.querySelectorAll('c-agn_gcsp_generate-input-field').forEach(element => {
                    if (element.fieldname === field.Field_Name_AGN__c
                        && element.sobjectname === field.SObject_Name_AGN__c) {
                            console.log('Checking the dependent List>>');
                            element.removeInputValue();
                        if (field.Dependent_Field_Show_Criteria_AGN__c.includes(controllingFieldSelectedValue)) {
                            element.showCmp();                            
                            this.showtest =true;
                            return;
                        }
                        else{
                            element.hideCmp();
                            this.showtest =false;
                            return;
                        }
                    }
                });
            }
            );
        }
    }

}