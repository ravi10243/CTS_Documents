import { LightningElement,api,track } from 'lwc';
import isguest from '@salesforce/user/isGuest';
import { NavigationMixin } from 'lightning/navigation';

import AGN_OAM_Header_CustomerRegistration from '@salesforce/label/c.AGN_OAM_Header_CustomerRegistration';

//import getCustomerRegDetails from '@salesforce/apex/AGN_CP_PortalCustomerRegStep2Controller.getCustomerRegDetails';
//import getCustomerAddressDetails from '@salesforce/apex/AGN_CP_PortalCustomerRegStep2Controller.getCustomerAddressDetails';

export default class Agn_gcsp_registrationWrapper extends NavigationMixin(LightningElement) {


    @track country;
    @track language;
    @track countryCode;
    @track customerType;
    @track customerSubType;
    @track countryOptions;
    @track customerTypeConfig;

    @track isGuestUser = isguest;
    @track stepNo =1;  
    @track showStep1 = false;
    @track showLoader;

    label = {
        AGN_OAM_Header_CustomerRegistration
    }


    connectedCallback() {

        var parameters = {};        
        parameters = this.getQueryParams();       
        this.showLoader = true;
        this.countryCode = parameters.country;
        console.log('Params>>'+JSON.stringify(parameters));
        if (parameters.language) {
            let langreg = parameters.language.split('_'); //it, en_AU, en_GB
            if (langreg.length === 2) {
                this.language = langreg[0];
                this.country = langreg[1].toUpperCase();
            }
            else {
                this.language = parameters.language;
                this.country = parameters.language.toUpperCase();
            }
            this.countryCode = this.country;
        }    
        this.showStep1 = false;
        //
        //this.isCompleted = false;
        //.hidemaindiv = false;
    }
    
    getQueryParams() {
        var params = {};
        var search = location.search.substring(1);
        if (search) {
            params = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
                return key === "" ? value : decodeURIComponent(value)
            });
        }
        return params;
    }
    handleSelection(event){

        this.showStep1 = false;
        console.log('<<Inside Event Handler>>>');
        const customerInfo = event.detail;
        //console.log('customerInfo>>>',JSON.stringify(customerInfo));
        this.customerType = customerInfo.type;
        this.customerSubType = customerInfo.subType;
        this.customerTypeConfig = customerInfo.customerConfig;
        this.countryOptions = customerInfo.picklistCountryOption;
        console.log('customerType>>>',this.customerType);
        console.log('customerTypeConfig>>>', this.customerTypeConfig);
        console.log('countryOptions>>>',this.countryOptions);
        console.log('customerSubType>>>',this.customerSubType);  
        this.showStep1 = true;    
        this.template.querySelector('c-agn_gcsp_customer-reg-step-1').refreshRegForm(this.customerType,this.customerSubType);


    }

    navigateToLink(pagename) {
        // Navigate to a URL
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: pagename
            }
        },
        false //Replaces the current page in your browser history with the URL
      );
    }

}