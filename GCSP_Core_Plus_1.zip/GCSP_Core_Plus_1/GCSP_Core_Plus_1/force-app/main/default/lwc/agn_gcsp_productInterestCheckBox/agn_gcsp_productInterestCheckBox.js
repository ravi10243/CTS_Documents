import { LightningElement, api, track } from 'lwc';
import {
    loadStyle
} from 'lightning/platformResourceLoader';
import ASSETS from '@salesforce/resourceUrl/AGN_GCSP_Assets';
import ASSETS1 from '@salesforce/resourceUrl/AGN_CustomerPortal_LWC';

export default class Agn_gcsp_productInterestCheckBox extends LightningElement {

    @api chklabel;
    @api chkval;
    @api ischecked;

    @api
    checkboxHandler(event){
       console.log(event.target.value);
        var chkSelectedEvent = new CustomEvent('chkboxselected', {
            detail: {
                selectedVal: event.target.value,
                isSelected : event.target.checked
            }
        });
        this.dispatchEvent(chkSelectedEvent);
    }

    renderedCallback() {
        loadStyle(this, ASSETS + '/assets/agn_gcsp_registration.css');
        loadStyle(this, ASSETS1 + '/css/style.css');   
        loadStyle(this, ASSETS1 + '/css/footer.css');     
    }
}