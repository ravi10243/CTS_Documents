import { api, LightningElement } from 'lwc';

// Apex Method to fetch Data List
import getDataList from '@salesforce/apex/AGN_AccountHierarchyDatatableHelper.getDataList';

// Apex Method to fetch column setup for datatable
import getColumnSetup from '@salesforce/apex/AGN_AccountHierarchyDatatableHelper.getColumnSetup';

// Apex Method to fetch flattening for datatable
import getFlatteningSchema from '@salesforce/apex/AGN_AccountHierarchyDatatableHelper.getFlatteningSchema';

// Message to display if no case records returned
const NORECORDS = 'No cases associated with this account';
// Creating Base URL
const ORGURL = 'https://allerganemea--hcoeudev.my.salesforce.com/';

export default class AccountHierarchyDatatable extends LightningElement {
    
    // Public variable to accept the Id of the account for which information is to be displayed
    @api accountId;
    // Public variable to accept the sObject type for which the data is to be displayed
    @api sObjectType;
    // Reactive variable to accept list of cases from imperative apex call, and display data
    records;
    // List of columns to be displayed in datatable
    columns;
    // Reactive variable to store if number of cases returned is greater than 0
    recordsReturned;
    
    // This variable set to false when component is inserted and to true when apex promise is completed
    // Controls spinner at component load  
    rendered;
    // Map of Labels
    label = {
        noRecords : NORECORDS
    };

    // Action to be executed on insertion of the component
    connectedCallback() {
        this.rendered = false;

    }

    // Action to be performed once all the public attributes are set by parent components.
    renderedCallback() {

        // Check to prevent recursive imperative call on render
        if(!this.rendered) {
            this.getSetup();
        }
    }

    // Method to call apex and get column setup and call data setup method once column setup is completed
    getSetup() {
        // Making imperative apex call to get column setup from settings
        getColumnSetup({ sObjectType: this.sObjectType })
            .then(result => {
                this.columns = JSON.parse(result);
                this.getData();
            })
            .catch(error => {
                this.wireError =  error.body.message;
            });
    }

    // Method to call apex and get data setup
    getData() {
        // Making imperative apex call to get data list and setting to record variable
        getDataList({ accountId: this.accountId, sObjectType: this.sObjectType })
            .then(result => {
                this.records =  result;
                this.recordsReturned = this.records.length > 0;
                this.getFlattenedData();
            })
            .catch(error => {
                this.wireError =  error.body.message;
            })            
    }

    // Method to call apex to get the flattening schema and flatten the json data retrieved
    getFlattenedData() {
    
        // Making imperative apex call to flattening schema and flatten the record variable
        getFlatteningSchema({ sObjectType: this.sObjectType })
            .then(result => {
                let flatteningSchema = JSON.parse(result);
                let flatteningPairs = Object.entries(flatteningSchema);

                // Flattening the records JSON for display and creating link
                if(this.records) {
                    let tempRecords = []; 
                    this.records.forEach(rec => {
                        let tempRecord = {};
                        tempRecord = rec;
                        tempRecord.recordUrl = ORGURL+rec.Id;

                        flatteningPairs.map(flatteningPair => {
                            let target = flatteningPair[0];
                            let sourceLevels = flatteningPair[1].split(".");

                            // Manual traversal through the relationship
                            // Condition till 5 added as only 5 relationships can be traversed in SOQL
                            if(sourceLevels.length == 2) {
                                tempRecord[target] = rec[sourceLevels[0]][sourceLevels[1]];
                            }
                            else if(sourceLevels.length == 3) {
                                tempRecord[target] = rec[sourceLevels[0]][sourceLevels[1]][sourceLevels[2]];
                            }
                            else if(sourceLevels.length == 4) {
                                tempRecord[target] = rec[sourceLevels[0]][sourceLevels[1]][sourceLevels[2]][sourceLevels[3]];
                            }
                            else if(sourceLevels.length == 5) {
                                tempRecord[target] = rec[sourceLevels[0]][sourceLevels[1]][sourceLevels[2]][sourceLevels[3]][sourceLevels[4]];
                            }
                        });
                        tempRecords.push(tempRecord);
                    });
                    this.records = tempRecords;
                }
            })
            .catch(error => {
                this.wireError =  error.body.message;
            })
            // Switching off loader spinner and allow display of data
            .finally(() => {
                this.rendered = true;
            });
            
    }
}