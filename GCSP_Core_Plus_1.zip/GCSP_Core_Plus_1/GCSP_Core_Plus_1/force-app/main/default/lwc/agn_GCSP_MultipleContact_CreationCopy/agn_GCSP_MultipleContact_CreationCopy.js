/**
 * @description       : 
 * @author            : Ravi Sirigiri
 * @group             : 
 * @last modified on  : 03-02-2021
 * @last modified by  : Ravi Sirigiri
 * Modifications Log 
 * Ver   Date         Author          Modification
 * 1.0   02-25-2021   Ravi Sirigiri   Initial Version
**/
import { LightningElement, wire,track,api } from 'lwc';
import NAME1_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.SAP_Name_1_AGN__c';
import ADDRESS_LINE_1_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Address_Line_1_AGN__c';
import COUNTRY_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Country_AGN__c';
import SOLD_TO_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Sold_To_AGN__c';
import SHIP_TO_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Ship_To_AGN__c';
import BILL_TO_FIELD from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Bill_To_AGN__c';

import getLayout from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.getLayout';
import fetchCountryList from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.fetchCountryList';
import getexistingData from '@salesforce/apex/AGN_GCSP_MultipleContactsController.doInit';
import saveAcrContactsAffiliation from '@salesforce/apex/AGN_GCSP_MultipleContactsController.saveAcrContactsAffiliation';


import {
    getCustomLable
} from 'c/aGN_GCSP_CustomLabelsComponent';


import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';

const addressColumns = [
    { label: 'Name', fieldName: NAME1_FIELD.fieldApiName, type:'text' },
    { label: 'Address Line 1', fieldName: ADDRESS_LINE_1_FIELD.fieldApiName, type:'text' },
    { label: 'Country', fieldName: COUNTRY_FIELD.fieldApiName, type:'text' },
    { label: 'Sold To', fieldName: SOLD_TO_FIELD.fieldApiName, type: 'boolean' },
    { label: 'Ship To', fieldName: SHIP_TO_FIELD.fieldApiName, type: 'boolean' },
    { label: 'Bill To', fieldName: BILL_TO_FIELD.fieldApiName, type: 'boolean' }
];

export default class Agn_GCSP_MultipleContact_CreationCopy extends LightningElement {
     data;
     error;
     flag = false;

    addrcols = addressColumns;

    @api caseId = '';
    @api sapId = '';
    
    @api existingSoldTo;
    @api existingShipTo;
    @api existingBillTo;

    addressList;
    registration;
    caseCr;
    acrContactList;
    sapContactsMap;
    contactSapMap;
    existingAffiliationList;

    hidemaindiv;
    showLoader;

    contactsoption;
    contactOptionValue;
    isExistingContacts;

    isShowDataTable;

    wrapperDataMap = new Map();

    layoutMetadataMaster;
    step5fields;
    customerTypeConfig;

    newcontactsMap = [];
    existingContactsMap = [];
    contactMapCounter = 0;

    showNewContactsLayout;

    country;

    afflAddr;

    get actionTypeOptions() {
        return [{
                label: 'New',
                value: 'new'
            },
            {
                label: 'Update',
                value: 'update'
            }
        ];
    }
   
    connectedCallback(){
        this.hidemaindiv = true;
        this.showLoader = true;
        this.getExistingContactsData();

       
    }


    getExistingContactsData(){

        getexistingData({
            caseId: this.caseId,
            sapId: this.sapId
        })
        .then( result => {

            if (result) {
                console.log('result at get existing contact info ::::', result);
                //this.addressList = result.addressList;
                
                this.sapContactsMap = result.customerDetailConMap;
                this.contactSapMap = result.conCustomerDetailMap;
                if (result.addressList) {
                    this.addExistingAddressToNewList(result.addressList);
                }
                this.registration = result.newRegistration;
                this.caseCr = result.newCase;
                this.acrContactList = result.acrContactList;
                if (this.acrContactList) {
                     this.isExistingContacts = true;
                     this.contactsoption = this.getcontactOptions(this.acrContactList);
                }
                let countryCode = '';
                countryCode = this.registration.SAP_Country_Code_AGN__c;
                if (!countryCode) {
                   countryCode = this.registration.Country_Code_AGN__c
                }
                this.country = countryCode;
                this.fetchCountryList(countryCode);
                
            }
            this.hidemaindiv = false;
            this.showLoader = false;
        })
        .catch(error => {
            console.log('error at get existing data::: ', error);
            this.hidemaindiv = false;
            this.showLoader = false;
        });
    }

    addExistingAddressToNewList(addlist){
        let addressList = [];
        var addressMap = new Map();
        let existingSoldToRec = this.existingSoldTo;
        let existingShipToRec = this.existingShipTo;
        let existingBillToRec = this.existingBillTo;
        
        var existingAddMap = new Map();
        if (addlist) {
            addlist.forEach(function (address) {                
                if (address.SAP_ID_AGN__c) {
                    existingAddMap.set(address.SAP_ID_AGN__c, address);
                }
                else{
                    addressList.push(address);
                }
            });
        }
        console.log('existingAddMap:::', existingAddMap);

       if (existingSoldToRec) {
           existingSoldToRec.forEach(function (soldTo) {
               addressMap.set(soldTo.SAP_ID_AGN__c, soldTo);
               if (existingAddMap.has(soldTo.SAP_ID_AGN__c)){
                   addressList.push(existingAddMap.get(soldTo.SAP_ID_AGN__c));
               }else{
                   addressList.push(soldTo);
               }
               
           });
       }
       if (existingShipToRec) {
           existingShipToRec.forEach(function (shiptTo) {
               addressMap.set(shiptTo.SAP_ID_AGN__c, shiptTo);
               if (existingAddMap.has(shiptTo.SAP_ID_AGN__c)) {
                   addressList.push(existingAddMap.get(shiptTo.SAP_ID_AGN__c));
               } else {
                   addressList.push(shiptTo);
               }
           });
       }
       if (existingBillToRec) {
           existingBillToRec.forEach(function (billTo) {
               addressMap.set(billTo.SAP_ID_AGN__c, billTo);
               if (existingAddMap.has(billTo.SAP_ID_AGN__c)) {
                   addressList.push(existingAddMap.get(billTo.SAP_ID_AGN__c));
               } else {
                   addressList.push(billTo);
               }
           });
       }
       
       if (!existingBillToRec && !existingShipToRec && !existingSoldToRec) {
           //let addressVal = existingAddMap.values();
           
           existingAddMap.forEach((value, key) => {
               console.log('mapvalue>>>> ',value);  
               addressList.push(value);
           });

       }
       console.log('addressList::::: ', addressList);
       this.addressList = addressList;


    }

    handleAddressRowSelection = e => {
        var selectedAddressRows = e.detail.selectedRows;

        if (selectedAddressRows.length > 0) {
            this.afflAddr = selectedAddressRows;

        }
    }    
  
    getcontactOptions(acrContacts){
        let options = [];
        acrContacts.forEach(function(contact){
            options.push({
                label: contact.First_Name_AGN__c + ' ' + contact.Last_Name_AGN__c,
                value: contact
            });
        });
        return options;
    }

    show_hide_contact(event) {
        
        var acrContact = event.target.value;
        console.log('edit button::::: ' + JSON.stringify(acrContact));

        this.template.querySelectorAll(`[data-id="${acrContact}"]`).forEach(element => {

            element.classList.toggle('Contact_add1');

        });
         this.template.querySelectorAll(`[data-value="${acrContact}"]`).forEach(element => {

             element.classList.toggle('Contact_add');

         });
    }
   

    fetchCountryList(countryCode) {

        fetchCountryList({
                countryCode: countryCode,
                source: 'cs'
            })
            .then(result => {
                var customerTypeConfig = result[1];
                this.customerTypeConfig = customerTypeConfig;
                // console.log('Data*******', JSON.stringify(this.customerTypeConfig)); 
                this.invokeGetLayout(this.registration, countryCode, customerTypeConfig);
            })
            .catch(error => {
                console.log('error IT Layout>>>>>>>>>>>>>>>>>>>', error);
                this.error = error;
            });

    }

    invokeGetLayout(registration, countryCode, customerTypeConfig) {
        //console.log('invokeGetLayout>>>>>>>>>>>>>>>', countryCode,registration,customerTypeConfig,this.stepNo);
        if (countryCode === 'IT') {
            getLayout({
                    country: countryCode,
                    stepNo: '5',
                    source: 'cs'
                })
                .then(result => {
                    this.setLayoutFields(result);
                    this.layoutMetadataMaster = result;

                })
                .catch(error => {
                    console.log('Error In Layout calllout :: ', error);
                    this.setErrorMessage(error, '');
                    this.showLoader = false;
                    this.hidemaindiv = false;
                });
        } else {           
            getLayout({
                    country: countryCode,
                    stepNo: '5',
                    customerType: registration.Customer_Category_AGN__c,
                    customerSubType: registration.Customer_Sub_Category_AGN__c,
                    custTypeConfig: customerTypeConfig,
                    source: 'cs'
                })
                .then(result => {
                    console.log('Layout Response :: ', result);
                    this.setLayoutFields(result);
                    this.layoutMetadataMaster = result;
                })
                .catch(error => {
                    console.log('Error In Layout calllout :: ', error);
                    this.setErrorMessage(error, '');
                    this.showLoader = false;
                    this.hidemaindiv = false;
                });
        }

    }

    setLayoutFields(data) {
        var settingsMap = data;
        var step5fields = [];
        // console.log('settingsMap>>>>>>>>>>>>>>>>>>', settingsMap);
        for (var key in settingsMap) {
            step5fields = settingsMap[key];
        }
        // console.log('step3fields2222>>>>>>>>>>>>>>>>>>', JSON.stringify(step3fields));  
        this.step5fields = step5fields;
        this.hidemaindiv = false;
        this.showLoader = false;
    }

    setErrorMessage(error, custommsg) {
        console.log('error == ', error);
        if (custommsg) {
            this.showToast('Error', ' Contact your administrator ::: ' + custommsg, 'Error');
        } else if (error && error.body && error.body.message) {
            this.showToast('Error', ' Contact your administrator ::: ' + error.body.message, 'Error');
        } else {
            this.showToast('Error', ' Unknown Error, Contact your administrator ', 'Error');
        }
    }

    showToast(title, message, variant) {
        if (this.source === 'cs') {
            this.error = message;
            this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
        } else {
            const event = new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            });
            this.dispatchEvent(event);
        }
    }

     deleteContact(event) {
         var indx = event.detail.index;
         var instancetype = event.detail.instancetype;
         if (instancetype === "new") {
             if (indx === 0 || indx > 0) {
                 console.log('index>>>>>>>>>>>>', indx);
                 var contactsMap = this.newcontactsMap;
                 console.log('contactsMap before delete>>>>>>>>>>>>>>>', contactsMap);
                 contactsMap.splice(indx, 1);
                 console.log('contactsMap after delete>>>>>>>>>>>>>>>', contactsMap);
                 this.newcontactsMap = contactsMap;
                 this.contactMapCounter--;
             }
            
             
         }
     }

     addNewContact(){
         console.log('this.contactMapCounter:::', this.contactMapCounter);
         var mapKey = 'Contact' + this.contactMapCounter;
         this.newcontactsMap.push({
             key: mapKey,
             value: this.step5fields
         });       
         this.showNewContactsLayout = true;
         this.contactMapCounter++;
         console.log('this.newcontactsMap::::', this.newcontactsMap);
     }


      handleControllingFieldEvent(event) {
          const eventParemeters = event.detail;

          const controllingFieldSobjectName = eventParemeters.controllingFieldSobjectName;
          console.log("controllingFieldSobjectName -> " + controllingFieldSobjectName);
          const controllingFieldName = eventParemeters.controllingFieldName;
          console.log("controllingFieldName -> " + controllingFieldName);
          const controllingFieldSelectedValue = eventParemeters.controllingFieldSelectedValue;
          console.log("controllingFieldSelectedValue -> " + controllingFieldSelectedValue);

          let dependentFieldList = [];
          //console.log("layoutMetadataMaster -> " + JSON.stringify(this.layoutMetadataMaster));
          //finding dependent field list based upon event received with parameters
          //console.log("layoutMetadataMaster Keys -> " +  Object.keys(this.layoutMetadataMaster));
          var itr = 1;
          Object.keys(this.layoutMetadataMaster).forEach(key => {
              console.log('layoutMetadataMaster[key]>>' + JSON.stringify(this.layoutMetadataMaster[key]));
              let dependentField = this.layoutMetadataMaster[key].find(layout => {
                  console.log('layout>>' + JSON.stringify(layout));
                  if (layout.Controlling_Field_AGN__c == controllingFieldName &&
                      layout.Controlling_Field_SObject_Name_AGN__c == controllingFieldSobjectName) {
                      console.log('itr>>' + itr);
                      itr++;
                      dependentFieldList.push(layout);
                      //return layout;

                  }
              });
              /*if (dependentField) {
                  dependentFieldList.push(dependentField);
              }*/
          });

          if (dependentFieldList.length > 0) {
              console.log('dependentFieldList>>>' + JSON.stringify(dependentFieldList));
              dependentFieldList.forEach(field => {
                  this.template.querySelectorAll('c-a-g-n_-g-c-s-p_-common-input-field-component').forEach(element => {
                      if (element.fieldname === field.Field_Name_AGN__c &&
                          element.sobjectname === field.SObject_Name_AGN__c) {
                          console.log('Checking the dependent List>>');
                          element.removeInputValue();
                          if (field.Dependent_Field_Show_Criteria_AGN__c.includes(controllingFieldSelectedValue)) {
                              element.showCmp();
                              console.log('met conditions>>');
                              this.showtest = true;
                              return;
                          } else {
                              element.hideCmp();
                              this.showtest = false;
                              return;
                          }
                      }
                  });
              });
          }
      }


    handleClick() {
        this.hidemaindiv = true;
        this.showLoader = true;
       
        var oldContactMap = new Map();
        let oldContactList = this.acrContactList;

        if (oldContactList) {
            oldContactList.forEach(function (acrCon) {                
                oldContactMap.set(acrCon.Contact_AGN__c, acrCon);
            });
        }

        let labelMap = getCustomLable();


        var customerObj = [];
        var contAddObj = [];
        var addContmapObj = [];
        let newcontactAffliation;
        let selectedAddRows;
        this.template.querySelectorAll('c-agn_gcsp_mange_accounts').forEach(element => {

            let contactsData = element.validateInputs();
            selectedAddRows = element.selectedAddRows();
            console.log('contactsData::::::' + JSON.stringify(contactsData));
            //console.log('selectedAddRows::::::' + JSON.stringify(selectedAddRows));
            newcontactAffliation = new Map();
            let addconObj = [];
            for (let value of contactsData) {
                if (selectedAddRows) {
                    for (let add of selectedAddRows) {
                        let acrContactAdd = {
                            'sobjectType': 'Allergan_Address_Contact_Mapping_agn__c'
                        };
                        if (add.Id) {
                            acrContactAdd.Allergan_Customer_Address_agn__c = add.Id;
                            addconObj.push(value);
                            newcontactAffliation = {
                                'key': add.Id,
                                'acrConList': value
                            };
                            addContmapObj.push(newcontactAffliation);
                        } else if (add.SAP_ID_AGN__c) {
                            addconObj.push(value);
                            acrContactAdd.External_Id_agn__c = add.SAP_ID_AGN__c;
                            //newcontactAffliation.set(add.SAP_ID_AGN__c, addconObj);
                            newcontactAffliation = {
                                'key': add.SAP_ID_AGN__c,
                                'acrConList': value
                            };
                            addContmapObj.push(newcontactAffliation);

                        }

                        //contAddObj.push(acrContactAdd);
                    }
                } else {
                    customerObj.push(value);
                }
            }
        });
        //customerMap.set

        if (contAddObj || customerObj) { //contAddObj,
            this.handleSavecustomerDetails(addContmapObj, customerObj, selectedAddRows);
        }

    }

    handleSavecustomerDetails(newconAffMap, customerObj, selectedAddRows) {
        //console.log('contAddObj>>>>>' + JSON.stringify(contAddObj));
        //console.log('newconAffMap>>>>>' + JSON.stringify(newconAffMap));
        //console.log('customerObj>>>>>' + JSON.stringify(customerObj));
       // console.log('selectedAddRows>>>>>' + JSON.stringify(selectedAddRows));  
       //addConList: contAddObj,
         saveAcrContactsAffiliation({
                 caseId: this.caseId,
                 contactAddMap: JSON.stringify(newconAffMap),
                 customerConList:customerObj,
                 addList: selectedAddRows
             })
             .then(result => {

                     if (result) {
                         console.log('result:::::', result);
                     }
                     this.hidemaindiv = false;
                     this.showLoader = false;
                 })
                 .catch(error => {
                     console.log('error at get existing data::: ', error);
                     this.hidemaindiv = false;
                     this.showLoader = false;
                 });
                 
    }

}