/************************************************************************************************************
@FileName:          duplicateListAGN.js 
@Version:           1.0
@Author:            Ayush Basak (ayush.basak@cognizant.com)
@Purpose:           Identify and list possible duplicate business account, based on the information captured 
                    on the Allergan Customer Address record. It also allows users to map and unmap identified 
                    business accounts with the Allergan Customer Address Record
-------------------------------------------------------------------------------------------------------------
@ Change history: 28.12.2020 / Ayush Basak / Created the file.
*************************************************************************************************************/
import { LightningElement, api, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { updateRecord, getRecord } from 'lightning/uiRecordApi';
import ACA_ID from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Id';
//import ACA_BA_ID from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Account_AGN__c';
import ACA_BA_ID from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Temp__c';
import ACA_BA_LOSER_ID from '@salesforce/schema/Allergan_Customer_Address_AGN__c.Initial_Account_AGN__c';
// Apex method to fetch duplicate business accounts
import getDuplicates from '@salesforce/apex/AGN_Duplicate_Checker.getDuplicates';

// Labels 
const ERROR_VARIANT = 'error';
const SUCCESS_VARIANT = 'success';
import NO_RECORDS from '@salesforce/label/c.AGN_Dupe_Checker_NoRecords';
import LOAD_ERRORS from '@salesforce/label/c.AGN_Dupe_Checker_Error';
import ERROR_TITLE from '@salesforce/label/c.AGN_Dupe_Checker_ErrorTitle';
import SUCCESS_TITLE from '@salesforce/label/c.AGN_Dupe_Checker_SuccessTitle';
import UPMAPPING_SUCCESS_MSG from '@salesforce/label/c.AGN_Dupe_Checker_ActionError';
import MAPPING_SUCCESS_MSG from '@salesforce/label/c.AGN_Dupe_Checker_ActionSuccess';
import COMPONENT_TITLE from '@salesforce/label/c.AGN_Dupe_Checker_Title';

export default class DuplicateListingAGN extends LightningElement {
    // Public variable to be set by parent component/page
    @api recordId;
    // Wired record to get Business Account currently stamped on the record
    @wire(getRecord, { recordId: '$recordId', 
                       fields: [ACA_BA_ID, ACA_BA_MAPPED_ID]
                     })
    recordDetail;
    // Reactive variable to accept the result set and display
    duplicateRecords;
    // Boolean to check if any records where returned
    recordsReturned;

    // Accept error messages from apex calls and display
    wireError;

    rendered = false; 
    
    // Constant string labels to be displayed on the component
    label = {
        noRecords: NO_RECORDS,
        loadErrors: LOAD_ERRORS,
        componentTitle: COMPONENT_TITLE
    }
    
    // Action to be performed on load
    // Making apex call to get the list of duplicate business accounts
    connectedCallback() {
        getDuplicates({ crAddressId: this.recordId })
            .then(result => {
                this.duplicateRecords = result;
                this.recordsReturned = this.duplicateRecords.length > 0;
                this.setupDynamicDisplay();
                this.checkMappedRecord();
            })
            .catch(error => {
                this.wireError =  error.body.message;
            })
            .finally(() => {
                this.rendered = true;
            });
    }

    // Button suport action, uses UpdateRecord method from uiRecordApi module to update the record.
    assignAccount(event) {

        // Getting the account id from event
        let selectedAccountId = event.target.dataset.key;
        let busAccountLooserId = this.recordDetail.data.fields[ACA_BA_LOSER_ID.fieldApiName].value;
        let busAccountId = this.recordDetail.data.fields[ACA_BA_ID.fieldApiName].value;
        // Setting up the record
        const fields = {};
        fields[ACA_ID.fieldApiName] = this.recordId;
        fields[ACA_BA_ID.fieldApiName] = selectedAccountId;
        // Check if looser id is already stamped or not, 
        if(busAccountLooserId == null) {
            fields[ACA_BA_LOSER_ID.fieldApiName] = busAccountId;
        }

        const recordInput = { fields };

        // Calling data service method
        updateRecord(recordInput)
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: SUCCESS_TITLE,
                        message: MAPPING_SUCCESS_MSG,
                        variant: SUCCESS_VARIANT
                    })
                );
                this.checkMappedRecord();
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: ERROR_TITLE,
                        message: error.body.message,
                        variant: ERROR_VARIANT
                    })
                );
            });
    }

    // Button suport action, uses UpdateRecord method from uiRecordApi module to update the record.
    unassignAccount(event) {

        // Setting up the record
        const fields = {};
        fields[ACA_ID.fieldApiName] = this.recordId;
        fields[ACA_BA_ID.fieldApiName] = null; // Setting Business Account field as blank
        const recordInput = { fields };

        // Calling data service method
        updateRecord(recordInput)
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: SUCCESS_TITLE,
                        message: UPMAPPING_SUCCESS_MSG,
                        variant: SUCCESS_VARIANT
                    })
                );
                this.checkMappedRecord();
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: ERROR_TITLE,
                        message: error.body.message,
                        variant: ERROR_VARIANT
                    })
                );
            });
    }

    // This method is called when data is loaded in the renderedCallback
    // This copies all the field map for each record and translates in to object list for display
    // This allows backend class to update field list without having to make changes in the component 
    // to add/remove fields
    setupDynamicDisplay() {
        let tempRecords = [];
        this.duplicateRecords.forEach(rec => {
            let tempRecord = rec; 
            let tempMap = [];
            for (const dataRow of Object.entries(rec.data)) {
                tempMap.push({key:dataRow[0], value:dataRow[1]});
            }
            tempRecord.dataSet = tempMap;
            tempRecord.data = null;
            tempRecords.push(tempRecord);
        });
        this.duplicateRecords = tempRecords;
    }

    // This method is called on renderedCallback, or everytime assign or unassigned actions are triggerd
    // This method checks for the currently mapped Business account Id on the record 
    // and controls the visibility of assign and unassign buttons
    checkMappedRecord() {
        let tempRecords = [];
        let busAccountLooserId = this.recordDetail.data.fields[ACA_BA_LOSER_ID.fieldApiName].value;
        let busAccountId = this.recordDetail.data.fields[ACA_BA_ID.fieldApiName].value;
        this.duplicateRecords.forEach(rec => {
            let tempRecord = rec; 
            tempRecord.isMapped = (rec.accountId == busAccountId); 

            // Checking if the returned value is already marked as looser
            if(rec.accountId != busAccountLooserId) {
                tempRecords.push(tempRecord);
            }
        });
        this.duplicateRecords = tempRecords;
    }
}