import { LightningElement,api,track,wire } from 'lwc';
import fetchCountryList from '@salesforce/apex/AGN_GCSP_PortalCustomerRegUtils.fetchCountryList';

import AGN_OAM_Body_CustomerType from '@salesforce/label/c.AGN_OAM_Body_CustomerType';
import AGN_OAM_Body_SubType from '@salesforce/label/c.AGN_OAM_Body_SubType';


export default class Agn_gcsp_customerTypeSelectionCmp extends LightningElement {


    @api country;
    @api language;
    @api countryCode;
    @api customerTypeConfig;
    @api selectedCustomerCategory;
    @api selectedCustomerSubCategory;
    @api isCompActive = false;
    @api picklistCountryOptions;

    @track picklistCustomerTypeOptions;
    @track picklistSubTypeOptions;
    
    @track showStep1;


    label = {
        AGN_OAM_Body_CustomerType,
        AGN_OAM_Body_SubType,
    }

    connectedCallback() {

        this.countryCode  = this.country;       
    }

    
    @wire(fetchCountryList, { countryCode: '$countryCode' }) countryConfig({ error, data }) {
        if (data) {
            this.picklistCountryOptions = data[0];
            var customerTypeConfig = data[1];
            this.customerTypeConfig = customerTypeConfig;
            this.populateCustomerCategoryDropDown(this.countryCode, this.customerTypeConfig);
        } else if (error) {
            // eslint-disable-next-line no-console
            console.log('error on header component>>>>>>>', error);
        }
    }
    

    customerCategoryChangeHandler(event) {
        const field = event.target.name;
        //console.log('field>>>>>>>>>>>', field);
        //console.log('selected value>>>>', event.target.value);
        //console.log('3customerTypeConfig>>:', this.customerTypeConfig);
        //if (field === 'customerCategorySelect') {
            //this.showStep1 = false;
            this.picklistSubTypeOptions = [];
            var selected = event.target.value;
            //var lang = this.language;
            var country = this.selectedCountry;
            this.selectedCustomerCategory = selected;
            //console.log('selected value>>>>', this.selectedCustomerCategory);
            if (selected) {
                var newlst = [];
                this.customerTypeConfig.forEach(function (currRow) {
                    /*if(currRow.Province_AGN__c && currRow.Category_AGN__c.toUpperCase() === selected.toUpperCase() && currRow.Province_AGN__c.includes(country.toUpperCase())){
                        if (newlst.map(function(e) { return e.key; e.val;}).indexOf(currRow.Sub_Category__c) <0){ // duplicate remove 
                             if(lang && lang === 'fr_CA' ){
                                newlst.push({key:currRow.Sub_Category__c, val:currRow.Sub_Category_Label_AGN__c});  
                            } else{
                                newlst.push({key:currRow.Sub_Category__c, val:currRow.Sub_Category__c});  
                            } 
                        }
                    }*/
                    //console.log('currRow.Category_AGN__c>>>>>>', currRow.Category_AGN__c);
                    //console.log('selected>>>>>>', selected);
                    if (currRow.Category_AGN__c.toUpperCase() === selected.toUpperCase()) {
                        if (newlst.map(function (e) { return e.key; }).indexOf(currRow.Sub_Category__c) < 0) { // duplicate remove
                            if (country === 'GB' || country === 'IE') {
                                if (currRow.Customer_Country_AGN__r.Name === country) {
                                    newlst.push({ key: currRow.Sub_Category__c, val: currRow.Sub_Category_Label_AGN__c });
                                }
                            } else {
                                newlst.push({ key: currRow.Sub_Category__c, val: currRow.Sub_Category_Label_AGN__c });
                            }
                        }
                    }
                });
                newlst.sort();               
                this.picklistSubTypeOptions = newlst;
            } else {
                this.showStep1 = false;
                this.picklistSubTypeOptions = [];
            }
        //}
    }

    populateCustomerCategoryDropDown(country, customerTypeConfig) {
        var newlst = [];
        var selected = country;
        this.selectedCountry = country;
        var itr = 1;
        customerTypeConfig.forEach(function (currRow) {
            //console.log('newlst itr>>'+ itr++,newlst);
            
            /*
            Canada related code - for Provice Picklist
            if(currRow.Province_AGN__c && currRow.Province_AGN__c.includes(selected.toUpperCase())){                        
                if(newlst.map(function(e){return e.key; e.val;}).indexOf(currRow.Category_AGN__c,currRow.Category_Label_AGN__c)<0){ 
                    if(lang && lang === 'fr_CA' ){
                        newlst.push({key:currRow.Category_AGN__c, val:currRow.Category_Label_AGN__c}); 
                    } else{
                        newlst.push({key:currRow.Category_AGN__c, val:currRow.Category_AGN__c}); 
                    }                            
                } 
            }*/

            if (selected.toUpperCase() === 'GB' || selected.toUpperCase() === 'IE') {
                if (currRow.Customer_Country_AGN__r.Name.toUpperCase() === selected.toUpperCase()) {
                    if (newlst.map(function (e) {
                        return e.key; e.val;
                    }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                        newlst.push({ key: currRow.Category_AGN__c, val: currRow.Category_Label_AGN__c });
                    }
                }
            }
            else {

                if (currRow.Country_Code_AGN__c.toUpperCase() === selected.toUpperCase()) {
                    if(newlst.findIndex(e => e.key==currRow.Category_AGN__c && e.val ==currRow.Category_Label_AGN__c)<0)
                    {
                        newlst.push({ key: currRow.Category_AGN__c, val: currRow.Category_Label_AGN__c });
                    }
                    /*if (newlst.map(function (e) {
                        return e.key; e.val;
                    }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                        newlst.push({ key: currRow.Category_AGN__c, val: currRow.Category_Label_AGN__c });
                    }*/
                }
            }

        });

        newlst.sort();
        this.picklistCustomerTypeOptions = newlst;
    }

    customerSubCategoryChangeHandler(event) {
        const field = event.target.name;
        //if (field === 'customerSubCategorySelect') {
            console.log('event.target.value>>>>>>>>>>>', event.target.value);
            var selected = event.target.value;
            this.selectedCustomerSubCategory = selected;
            var country = this.selectedCountry;

            const onchangeOfSubcategory = new CustomEvent('subcatergoryselected', { detail: {
                type : this.selectedCustomerCategory,
                subType : this.selectedCustomerSubCategory,
                customerConfig :  this.customerTypeConfig,
                picklistCountryOption : this.picklistCountryOptions
            }});
            this.dispatchEvent(onchangeOfSubcategory);
           /* this.getLayoutForInternational(country, this.selectedCustomerCategory,
                this.selectedCustomerSubCategory, this.customerTypeConfig);
            if (selected) {
                this.showStep1 = true;
            } else {
                this.showStep1 = false;
            }
            */

            //this.formHeaderChangeHandler(this.selectedCountry , this.selectedCustomerCategory , this.selectedCustomerSubCategory , this.picklistCountryOptions , this.customerTypeConfig);
        //}
    }
    @api
    getCountrySFCode(country) {
        var countryobj;
        this.picklistCountryOptions.forEach(function (currRow) {
            if (currRow.Alpha_2_Code_vod__c.toUpperCase() === country.toUpperCase()) {
                countryobj = { 'countrySFDCId': currRow.Id, 'countryName': currRow.AGN_Country_Name__c };
            }
        });
        return countryobj;
    }
    



}