/**
 * @description       : 
 * @author            : Ravi Sirigiri
 * @group             : 
 * @last modified on  : 03-25-2021
 * @last modified by  : Ravi Sirigiri
 * Modifications Log 
 * Ver   Date         Author          Modification
 * 1.0   03-25-2021   Ravi Sirigiri   Initial Version
**/
import { LightningElement, api, wire } from 'lwc';
//import getFieldMetadata from '@salesforce/apex/AGN_GCSP_MetadataController.getFieldMetadata';
import { getObjectInfos } from 'lightning/uiObjectInfoApi';
export default class Agn_gcsp_metaDataComponent extends LightningElement {
    @api sobjectname;
    @api fieldname;
    objectApiname =[];
    connectedCallback(){
        this.getObjectMetadata(this.sobjectname);
        this.objectApiname.push('Allergan_Customer_Registration_AGN__c');
        this.objectApiname.push('Allergan_Customer_Contact_AGN__c');
        this.objectApiname.push('Allergan_Customer_Address_AGN__c');

        console.log('this.objectApiname::::::',this.objectApiname);
    }

     @wire(getObjectInfos, { objectApiNames: '$objectApiname' })
     objectInfo({ error, data }) {
        if (data) {
        //let fieldInfos = data.fields;    
          console.log('Object Data:::::::::'+JSON.stringify(data));
        this.error = undefined;

        } else if (error) {
            console.log('Error get Object Info::::::: ', error);
        }
     };
   

    getObjectMetadata(sobjectname){
        console.log('sobjectname:::::::',sobjectname);
    }
}