/* eslint-disable no-console */
import { LightningElement, api, track } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import { NavigationMixin } from 'lightning/navigation';
import isGuestUserSession from '@salesforce/user/isGuest';
import ASSETS from '@salesforce/resourceUrl/AGN_CP_Assets';

import validateAndLogInOkta from "@salesforce/apex/AGN_GCSP_OktaLoginController.validateAndLogInOkta";
import USERNAME from "@salesforce/label/c.AGN_OAM_Body_Username";
import PASSWORD from "@salesforce/label/c.AGN_OAM_Body_Password";
import FORGOTPASSWORD from "@salesforce/label/c.AGN_OAM_Body_ForgotPassword";
import SIGNIN from "@salesforce/label/c.AGN_OAM_Body_SignIn";
import SIGNUPNOW from "@salesforce/label/c.AGN_OAM_Body_SignUpNow";
import USERLOGIN from "@salesforce/label/c.AGN_OAM_Body_UserLogIn";
const DELAY = 3000;
export default class Agn_gcsp_loginPage extends NavigationMixin(LightningElement) {

  @api backgroundImageUrl = ASSETS + '/assets/Images/Homepage_bg.jpg';
  @api agnLogo = ASSETS + '/assets/Images/Allergan_White.png';

  renderedCallback() {
    loadStyle(this, ASSETS + '/assets/cp_login.css');
  }

  @track oktaUserNameString;
  @track oktaPasswordString;
  @track error;
  @api forgotPasswordUrl;
  @api createAccountUrl;

  label = {
    USERNAME,
    PASSWORD,
    FORGOTPASSWORD,
    SIGNIN,
    SIGNUPNOW,
    USERLOGIN
  };

  connectedCallback() {
    console.log('isGuestUserSession ->' + isGuestUserSession);
    //this.oktaUserNameString = "customerportaltest@yopmail.com";
    //this.oktaPasswordString = "Asdf@1234";
  }
  handleFormInputChange(event) {
    if (event.target.name === "txtUsername") {
      this.oktaUserNameString = event.target.value;
    } else if (event.target.name === "txtPassword") {
      this.oktaPasswordString = event.target.value;
    }
  }
  handleLogin() {
    this.error = undefined;
    const allValid = [
      ...this.template.querySelectorAll("lightning-input")
    ].reduce((validSoFar, inputCmp) => {
      inputCmp.reportValidity();
      return validSoFar && inputCmp.checkValidity();
    }, true);

    if (allValid) {
      validateAndLogInOkta({
        oktaUserName: this.oktaUserNameString,
        oktaPassword: this.oktaPasswordString
      })
        .then(result => {
          let data = JSON.parse(result);
          //console.log(data);
          if (data.isSuccess) {
            window.location.href = data.response;
          } else {
            this.error = data.response;
            console.log('@@data@@ ' + data.response);
            this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
          }
        })
        .catch(error => {
          console.error(error);
        });
    }
  }
  clearErrorMessage() {
    window.clearTimeout(this.delayTimeout);
    // eslint-disable-next-line @lwc/lwc/no-async-operation
    this.delayTimeout = setTimeout(() => {
      this.error = undefined;
    }, DELAY);
  }

  navigateToLink() {
    //var namedPage = event.target.dataset.namedpage;
    // Navigate to a URL
    this[NavigationMixin.Navigate]({
      type: 'comm__namedPage',
      attributes: {
        pageName: this.createAccountUrl
      }
    },
      false //Replaces the current page in your browser history with the URL
    );
  }
}