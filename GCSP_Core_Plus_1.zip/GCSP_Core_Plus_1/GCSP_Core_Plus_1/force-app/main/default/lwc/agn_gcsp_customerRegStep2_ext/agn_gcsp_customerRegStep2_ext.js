/**
 * @description       : 
 * @author            : Ravi Sirigiri
 * @group             : 
 * @last modified on  : 02-03-2021
 * @last modified by  : Ravi Sirigiri
 * Modifications Log 
 * Ver   Date         Author          Modification
 * 1.0   01-05-2021   Ravi Sirigiri   Initial Version
 **/
import {
    LightningElement,
    wire,
    track,
    api
} from 'lwc';
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
import {
    NavigationMixin
} from 'lightning/navigation';
import AGN_OAM_Body_Country from '@salesforce/label/c.AGN_OAM_Body_Country';
import AGN_OAM_Body_CustomerType from '@salesforce/label/c.AGN_OAM_Body_CustomerType';
import AGN_OAM_Body_SubType from '@salesforce/label/c.AGN_OAM_Body_SubType';
import AGN_OAM_Apex_DuplicateEmail from '@salesforce/label/c.AGN_OAM_Apex_DuplicateEmail';
import AGN_OAM_Body_Confirm_Youhave from '@salesforce/label/c.AGN_OAM_Body_Confirm_Youhave';
import AGN_OAM_Body_Confirm_SuccessfullyCompleted from '@salesforce/label/c.AGN_OAM_Body_Confirm_SuccessfullyCompleted';
import AGN_OAM_Body_Confirm_FirstStep from '@salesforce/label/c.AGN_OAM_Body_Confirm_FirstStep';
import AGN_OAM_Communication_Contact from '@salesforce/label/c.AGN_OAM_Communication_Contact';
import AGN_OAM_Address from '@salesforce/label/c.AGN_OAM_Address';
import AGN_OAM_Basic_Information from '@salesforce/label/c.AGN_OAM_Basic_Information';
import AGN_GCSP_AllFieldMandatory from '@salesforce/label/c.AGN_GCSP_AllFieldMandatory';
import AGN_OAM_Confirm_not_robot from '@salesforce/label/c.AGN_OAM_Confirm_not_robot';

import AGN_OAM_Please_Confirm from '@salesforce/label/c.AGN_OAM_Please_Confirm';
import AGN_OAM_Privacy_Policy from '@salesforce/label/c.AGN_OAM_Privacy_Policy';
import AGN_OAM_Body_TermsConditions from '@salesforce/label/c.AGN_OAM_Body_TermsConditions';
import AGN_OAM_Header_CustomerRegistration from '@salesforce/label/c.AGN_OAM_Header_CustomerRegistration';
import AGN_OAM_Product_Interest from '@salesforce/label/c.AGN_OAM_Product_Interest';
import AGN_OAM_Body_Submit from '@salesforce/label/c.AGN_OAM_Body_Submit';
import AGN_OAM_Next from '@salesforce/label/c.AGN_OAM_Next';
import AGN_OAM_Loading from '@salesforce/label/c.AGN_OAM_Loading';
import AGN_OAM_CS from '@salesforce/label/c.AGN_OAM_CS';
import AGN_OAM_Country_IE from '@salesforce/label/c.AGN_OAM_Country_IE';
import AGN_OAM_Country_GB from '@salesforce/label/c.AGN_OAM_Country_GB';
import AGN_OAM_IT from '@salesforce/label/c.AGN_OAM_IT';

import AGN_OAM_Body_CommunicationContact from '@salesforce/label/c.AGN_OAM_Body_CommunicationContact';
import AGN_OAM_Unknown_Err from '@salesforce/label/c.AGN_OAM_Unknown_Err';
import AGN_OAM_Contact_Service from '@salesforce/label/c.AGN_OAM_Contact_Service';
import AGN_OAM_Inactive_State from '@salesforce/label/c.AGN_OAM_Inactive_State';
import AGN_OAM_Valid_Input from '@salesforce/label/c.AGN_OAM_Valid_Input';
import AGN_OAM_Invalid_Input from '@salesforce/label/c.AGN_OAM_Invalid_Input';
import AGN_OAM_Captcha_Error from '@salesforce/label/c.AGN_OAM_Captcha_Error';


/*import {
    FlowAttributeChangeEvent,
    FlowNavigationNextEvent
} from 'lightning/flowSupport'; */

import fetchCountryList from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.fetchCountryList';
import getLayout from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.getLayout';
import createAccount from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createAccount';
import createContact from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createContact';
import createCommunityUser from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createCommunityUser';
import createNewCustomerRegistration from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createNewCustomerRegistration';
import createOktaUserSendLink from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createOktaUserSendLink';
import isDuplicateUser from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.isDuplicateUser';
import getCustomerRegDetailsCS from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.getCustomerRegDetailsCS';
import getCustomerAddressDetails from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.getCustomerAddressDetails';
import getCaseDetails from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.getCaseDetails';
import getcustomerContactDetails from '@salesforce/apex/AGN_GCSP_CustomerRegStep2Controller.getcustomerContactDetails';
import createNewCustomerRegistrationCS from '@salesforce/apex/AGN_GCSP_CustomerRegStep1Controller.createNewCustomerRegistrationCS';

import {
    loadStyle
} from 'lightning/platformResourceLoader';
import ASSETS from '@salesforce/resourceUrl/AGN_GCSP_Assets';
import ASSETS1 from '@salesforce/resourceUrl/AGN_CustomerPortal_LWC';


export default class Agn_gcsp_customerRegStep2_ext extends LightningElement {
    @api box_img_step1_active = ASSETS + '/assets/Images/Registration/box_img_step1_active.png';
    @api country = '';
    @api language = '';
    @track selectedCountry;
    @track selectedCustomerCategory;
    @track selectedCustomerSubCategory;
    @track picklistCountryOptions;
    @track picklistCustomerTypeOptions;
    @track picklistSubTypeOptions;
    @track customerTypeConfig;
    @track showStep1;
    @track productIntSection = false;
    @track stepNo;
    @track basicInformationFields;
    @track practiceAddressFields;
    @track productInterestFields;
    @track contactFields;
    @track showLoader;
    @track isCompleted;
    @track hidemaindiv;

    @track customerType;
    @track customerSubType;
    @track custTypeConfig;
    @track customerGroup;

    @track account;
    @track contact;
    @track countryCode = '';
    @track sapCountryCode = '';
    @track disableSubmitBtn = true;
    @track layoutMetadataMaster;
    @track isOnlineRegistration = false;

    @track soldToAddress;
    @track registrationRec;
    @track acrContact;
    @track caseRecord;
    @track showDisSelection =false;
    @track error;
    @track selectedProductInterest=[];

    @track captchaurl = 'https://hcoeudev-allergancommunityeu.cs129.force.com/customerPortal/AGN_GoogleCAPTCHAv2';
    @track iscaptchavalid = false;
    @track baseurl = 'https://hcoeudev-allergancommunityeu.cs129.force.com';

    @track termsURL;
    @track record;
    @api source = null;
    @api sourceOAM = null;
    @api sourceCS = null;

    @api RegistrationStepNo;
    @api caseId;
    @api accountId;

    label = {
        AGN_OAM_Body_Country,
        AGN_OAM_Body_CustomerType,
        AGN_OAM_Body_SubType,
        AGN_OAM_Apex_DuplicateEmail,
        AGN_OAM_Body_Confirm_Youhave,
        AGN_OAM_Body_Confirm_SuccessfullyCompleted,
        AGN_OAM_Body_Confirm_FirstStep,
        AGN_OAM_Basic_Information,
        AGN_OAM_Address,
        AGN_OAM_Communication_Contact,
        AGN_GCSP_AllFieldMandatory,
        AGN_OAM_Confirm_not_robot,
        AGN_OAM_Header_CustomerRegistration,
        AGN_OAM_Product_Interest,
        AGN_OAM_Please_Confirm,
        AGN_OAM_Privacy_Policy,
        AGN_OAM_Body_TermsConditions,
        AGN_OAM_Body_Submit,
        AGN_OAM_Next,
        AGN_OAM_Loading,
        AGN_OAM_CS,
        AGN_OAM_Country_IE,
        AGN_OAM_Country_GB,
        AGN_OAM_IT,
        AGN_OAM_Body_CommunicationContact,
        AGN_OAM_Unknown_Err,
        AGN_OAM_Contact_Service,
        AGN_OAM_Inactive_State,
        AGN_OAM_Valid_Input,
        AGN_OAM_Invalid_Input,
        AGN_OAM_Captcha_Error        

    };

    renderedCallback() {
        loadStyle(this, ASSETS + '/assets/agn_gcsp_registration.css');
        loadStyle(this, ASSETS1 + '/css/style.css');   
        loadStyle(this, ASSETS1 + '/css/footer.css');     
    }

    connectedCallback() {
        //alert('step1::' + this.sourceCS);
        if (this.sourceOAM && this.sourceOAM === 'oam') {
            this.source = this.sourceOAM;
            this.isOnlineRegistration = true;
        }
        if (this.sourceCS && this.sourceCS === 'cs') { //AGN_OAM_CS
            this.source = this.sourceCS;
            this.iscaptchavalid = true;
        }
        console.log('source :::::: ', this.source);
        var parameters = {};
        this.showStep1 = false;
        this.isCompleted = false;
        this.hidemaindiv = false;
        parameters = this.getQueryParams(); //get url parameters
        this.showLoader = true;

        if (parameters.language) {
            let langreg = parameters.language.split('_'); //it, en_AU, en_GB
            if (langreg.length === 2) {
                this.language = langreg[0];
                this.country = langreg[1].toUpperCase();
            } else {
                this.language = parameters.language;
                this.country = parameters.language.toUpperCase();
            }
            console.log('language-->' + this.language);
            console.log('country-->' + this.country);

            this.showStep1 = false;
            this.isCompleted = false;
            this.hidemaindiv = false;
        }
        if (parameters.country) {
            this.country = parameters.country.toUpperCase();
        }

        if (this.sourceCS === 'cs') { //AGN_OAM_CS
            if (parameters) {
                var caseService = parameters.caseService;
                var caseStaticCategory = parameters.caseStaticCategory;
                var selectedCountryCode = parameters.countryCode; //countryCode
                var recordType = parameters.recordType;
                var entitlementId = parameters.entitlementId;
                var caseCategory = parameters.caseCategory;
                var caseReason = parameters.caseReason;
                console.log('caseService:: ' + caseService + ':: ' + caseStaticCategory + '::  ' + recordType + ':::  ' + entitlementId + '::  ' + caseCategory + ':::  ' + caseReason);
                console.log('selectedCountryCode::::::', selectedCountryCode);
                this.country = selectedCountryCode;
            }

            if (this.caseId) {
                this.getCustomerRegistrationDetailsCS();
            }
        }

        if (this.country && this.country === AGN_OAM_Country_IE) {
            this.countryCode = AGN_OAM_Country_GB;
            this.sapCountryCode = AGN_OAM_Country_IE;
        } else {
            this.countryCode = this.country;
            this.sapCountryCode = this.country;
        }  
        
    /*if(window.addEventListener){            
        window.addEventListener("message", (event) =>{​​​​
            this.listenMessage(event)
        }​​​​, false);
    }​​​​ else{​​​​
        window.attachEvent("onmessage", (event) =>{​​​​
            this.listenMessage(event)
        }​​​​, false);
    }​​​​*/
        
       window.addEventListener("message", (event) => {
            console.log("action>>"+event.data.action);
            console.log("alohaResponseCAPTCHA>>"+event.data.alohaResponseCAPTCHA);
            console.log("origin>>"+event.origin);  
            if(event.data.action == 'alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'NOK'){              
                this.iscaptchavalid  = false;          
            }
            else if(event.data.action == 'alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'OK'){
                
                console.log("Captcha Success1");
                this.iscaptchavalid  = true;
                console.log("Captcha Success2>>" +  this.iscaptchavalid);
            }
        
        }, false);
      

    }

    getCustomerRegistrationDetailsCS() {
        getCustomerRegDetailsCS({
                caseRecId: this.caseId
            })
            .then(result => {
                console.log('Registration Response :: ', result);
                if (result) {
                    let registration = {
                        'sobjectType': 'Allergan_Customer_Registration_AGN__c'
                    };
                    this.registrationRec = result;
                    var countryCode = result.SAP_Country_Code_AGN__c;
                    if (!countryCode) {
                        countryCode = result.Country_Code_AGN__c;
                    }
                    this.country = countryCode;
                    this.customerType = result.Customer_Category_AGN__c;
                    this.customerSubType = result.Customer_Sub_Category_AGN__c;
                    this.language = result.Language_AGN__c;
                    this.stepNo = 1;
                    this.getAddressDetails(result, countryCode);
                    this.getCaseRecordDetails();
                    this.getCustomerContactDetails(result.Id);                    
                    this.showDisSelection = true;

                    this.getLayoutForInternational(countryCode, this.customerType,
                    this.customerSubType, this.customerTypeConfig);

                    this.showStep1 = true;

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.setErrorMessage('', AGN_OAM_Unknown_Err);
                }
            })
            .catch(error => {
                console.log('Error in Registration :: ', error);
                this.setErrorMessage(error, '');
                this.showLoader = false;
                this.hidemaindiv = false;
            });
    }
    getCaseRecordDetails() {
        getCaseDetails({
                caseId: this.caseId
            })
            .then(result => {
                console.log('Case Response :: ', result);
                if (result) {
                    let caseInfo = {
                        'sobjectType': 'Case'
                    };
                    this.caseRecord = result;

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.setErrorMessage('', AGN_OAM_Unknown_Err);
                }
            })
            .catch(error => {
                console.log('Error in Case :: ', error);
                this.setErrorMessage(error, '');
                this.showLoader = false;
                this.hidemaindiv = false;
            });
    }
    getCustomerContactDetails(regId) {
        getcustomerContactDetails({
                custRegId: regId
            })
            .then(result => {
                console.log('allergan customer contact Response :: ', result);
                if (result) {
                    let acrContactRec = {
                        'sobjectType': 'Allergan_Customer_Contact_AGN__c'
                    };
                    this.acrContact = result;
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.setErrorMessage('', AGN_OAM_Unknown_Err);
                }
            })
            .catch(error => {
                console.log('Error in Case :: ', error);
                this.setErrorMessage(error, '');
                this.showLoader = false;
                this.hidemaindiv = false;
            });
    }

    getAddressDetails(registration, countryCode) {

        getCustomerAddressDetails({
                custRegId: registration.Id
            })
            .then(data => {
                if (data) {
                    console.log("Address Response Callout :: ", data);
                    var soldToAddr;
                    var addressList = data;
                    for (var i in addressList) {
                        if (addressList[i].Sold_To_AGN__c) {
                            //only 1 SoldTo Address will be present
                            soldToAddr = addressList[i];
                        }
                    }
                    this.soldToAddress = soldToAddr;

                    this.mergeRegAddRecords();

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.setErrorMessage('', AGN_OAM_Unknown_Err);
                }
            })
            .catch(error => {
                console.log('Error in Address Callout :: ', error);
                this.setErrorMessage(error, '');
                this.showLoader = false;
                this.hidemaindiv = false;
            });
    }

    mergeRegAddRecords() {
        let objmix = Object.assign({}, this.registrationRec, this.soldToAddress); //Merging registration and address data
        this.record = objmix;
        this.showLoader = false;
    }

    navigateToLink(pagename) {
        // Navigate to a URL
        this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: pagename
                }
            },
            false //Replaces the current page in your browser history with the URL
        );
    }
    getQueryParams() {
        var params = {};
        var search = location.search.substring(1);
        if (search) {
            params = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
                return key === "" ? value : decodeURIComponent(value)
            });
        }
        return params;
    }
    /*************Country Dropdown Functionality - Below*******************/

    @wire(fetchCountryList, {
        countryCode: '$countryCode',
        source: '$source'
    }) countryConfig({
        error,
        data
    }) {
        if (data) {
            console.log('Header Data*******', data[1]);
            this.picklistCountryOptions = data[0];
            var customerTypeConfig = data[1];
            this.customerTypeConfig = customerTypeConfig;
            this.populateCustomerCategoryDropDown(this.countryCode, customerTypeConfig);
            this.showLoader = false;
        } else if (error) {
            console.log('error on header component>>>>>>>', error);
            this.showLoader = false;
        }
    }

    countryChangeHandler(event) {
        const field = event.target.name;
        console.log('field>>>>>>>>>>>>>>>>>', field);
        console.log(event);
        console.log('event.target.value>>>>>>>>>>>', event.target.value);
        var newlst = [];
        if (field === 'countrySelect') {
            var selected = event.target.value;
            //var lang = this.language;
            console.log('selected value>>>>', selected);
            this.selectedCountry = selected;
            console.log('selected country>>>>', this.selectedCountry);
            console.log('selected language>>>>', this.language);
            this.customerTypeConfig.forEach(function (currRow) {


                if (selected.toUpperCase() === AGN_OAM_Country_GB || selected.toUpperCase() === AGN_OAM_Country_IE) {
                    if (currRow.Customer_Country_AGN__r.Name.toUpperCase() === selected.toUpperCase()) {
                        if (newlst.map(function (e) {
                                return e.key;
                                e.val;
                            }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                            newlst.push({
                                key: currRow.Category_AGN__c,
                                val: currRow.Category_Label_AGN__c
                            });
                        }
                    }
                } else {
                    if (currRow.Country_Code_AGN__c.toUpperCase() === selected.toUpperCase()) {
                        if (newlst.map(function (e) {
                                return e.key;
                                e.val;
                            }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                            newlst.push({
                                key: currRow.Category_AGN__c,
                                val: currRow.Category_Label_AGN__c
                            });
                        }
                    }
                }


            });

            newlst.sort();
            this.picklistCustomerTypeOptions = newlst;

        }
    }

    populateCustomerCategoryDropDown(country, customerTypeConfig) {
        var newlst = [];
        var selected = country;
        var lang = this.language;
        this.selectedCountry = country;
        var sourceVal = this.source;

        customerTypeConfig.forEach(function (currRow) {
            var categoryLableValue = '';
            if (sourceVal === 'cs') { //AGN_OAM_CS
                categoryLableValue = currRow.Category_AGN__c;
            } else {
                categoryLableValue = currRow.Category_Label_AGN__c;
            }

            /*
            Canada related code - for Provice Picklist
            if(currRow.Province_AGN__c && currRow.Province_AGN__c.includes(selected.toUpperCase())){                        
                if(newlst.map(function(e){return e.key; e.val;}).indexOf(currRow.Category_AGN__c,currRow.Category_Label_AGN__c)<0){ 
                    if(lang && lang === 'fr_CA' ){
                        newlst.push({key:currRow.Category_AGN__c, val:currRow.Category_Label_AGN__c}); 
                    } else{
                        newlst.push({key:currRow.Category_AGN__c, val:currRow.Category_AGN__c}); 
                    }                            
                } 
            }*/

            if (selected.toUpperCase() === AGN_OAM_Country_GB || selected.toUpperCase() === AGN_OAM_Country_IE) {
                if (currRow.Customer_Country_AGN__r.Name.toUpperCase() === selected.toUpperCase()) {

                    if (newlst.map(function (e) {
                            return e.key;
                            e.val;
                        }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                        newlst.push({
                            key: currRow.Category_AGN__c,
                            val: categoryLableValue
                        });
                    }
                }
            } else {
                if (currRow.Country_Code_AGN__c.toUpperCase() === selected.toUpperCase()) {
                    if (newlst.map(function (e) {
                            return e.key;
                            e.val;
                        }).indexOf(currRow.Category_AGN__c, currRow.Category_Label_AGN__c) < 0) {
                        newlst.push({
                            key: currRow.Category_AGN__c,
                            val: categoryLableValue
                        });
                    }
                }
            }

        });

        newlst.sort();
        this.picklistCustomerTypeOptions = newlst;
    }

    customerCategoryChangeHandler(event) {
        this.showLoader = true;
        const field = event.target.name;
        console.log('field>>>>>>>>>>>', field);
        console.log('selected value>>>>', event.target.value);
        console.log();
        //if (field === 'customerCategorySelect') {
        this.showStep1 = false;
        this.picklistSubTypeOptions = [];
        var selected = event.target.value;
        var lang = this.language;
        var country = this.selectedCountry;
        this.selectedCustomerCategory = selected;
        var sourceVal = this.source;
        console.log('selected value>>>>', this.selectedCustomerCategory);
        if (selected) {
            var newlst = [];

            this.customerTypeConfig.forEach(function (currRow) {
                var subCategoryLableValue = '';
                if (sourceVal === 'cs') { //AGN_OAM_CS
                    subCategoryLableValue = currRow.Sub_Category__c;
                } else {
                    subCategoryLableValue = currRow.Sub_Category_Label_AGN__c;
                }
                /*if(currRow.Province_AGN__c && currRow.Category_AGN__c.toUpperCase() === selected.toUpperCase() && currRow.Province_AGN__c.includes(country.toUpperCase())){
                    if (newlst.map(function(e) { return e.key; e.val;}).indexOf(currRow.Sub_Category__c) <0){ // duplicate remove 
                         if(lang && lang === 'fr_CA' ){
                            newlst.push({key:currRow.Sub_Category__c, val:currRow.Sub_Category_Label_AGN__c});  
                        } else{
                            newlst.push({key:currRow.Sub_Category__c, val:currRow.Sub_Category__c});  
                        } 
                    }
                }*/
                //console.log('currRow.Category_AGN__c>>>>>>', currRow.Category_AGN__c);
                //console.log('selected>>>>>>', selected);
                if (currRow.Category_AGN__c.toUpperCase() === selected.toUpperCase()) {
                    if (newlst.map(function (e) {
                            return e.key;
                        }).indexOf(currRow.Sub_Category__c) < 0) { // duplicate remove
                        if (country === AGN_OAM_Country_GB || country === AGN_OAM_Country_IE) {
                            if (currRow.Customer_Country_AGN__r.Name === country) {
                                newlst.push({
                                    key: currRow.Sub_Category__c,
                                    val: subCategoryLableValue

                                });
                            }
                        } else {
                            newlst.push({
                                key: currRow.Sub_Category__c,
                                val: subCategoryLableValue
                            });
                        }
                    }
                }
            });
            newlst.sort();
            // console.log('sub category list>>>>>>>>>>>>>>>', newlst);
            this.picklistSubTypeOptions = newlst;
            this.showLoader = false;
        } else {
            this.showLoader = false;
            this.showStep1 = false;
            this.picklistSubTypeOptions = [];
        }
        //}
    }

    customerSubCategoryChangeHandler(event) {
        this.showLoader = true;
        const field = event.target.name;
        console.log('event.target.value>>>>>>>>>>>', event.target.value);
        var selected = event.target.value;
        this.selectedCustomerSubCategory = selected;
        var country = this.selectedCountry;
        console.log('country>>>>>>>>>>>', country);
        this.getLayoutForInternational(country, this.selectedCustomerCategory,
            this.selectedCustomerSubCategory, this.customerTypeConfig);
        if (selected) {
            this.showStep1 = true;
        } else {
            this.showStep1 = false;
        }
    }

    getLayoutForInternational(countryCode, customerType, customerSubType, customerTypeConfig) {
        console.log('countryCode:::: ', countryCode);
        console.log('customerType:::: ', customerType);
        console.log('customerSubType:::: ', customerSubType);
        console.log('customerTypeConfig:::: ', customerTypeConfig);
        console.log('this.source ', this.source);
        if (countryCode === "IT") {
            getLayout({
                    country: countryCode,
                    stepNo: '1',
                    source: this.source
                })
                .then(result => {
                    this.setLayoutFields(result);
                    console.log('setLayoutFields>>>>>>>>>>>>>>>>>>',result);
                    this.layoutMetadataMaster = result;
                })
                .catch(error => {
                    console.log('error IT Layout>>>>>>>>>>>>>>>>>>>', error);
                    this.error = error;
                });
        } else {

            getLayout({
                    country: countryCode,
                    stepNo: '1',
                    customerType: customerType,
                    customerSubType: customerSubType,
                    custTypeConfig: customerTypeConfig,
                    source: this.source
                })
                .then(result => {
                    this.setLayoutFields(result);
                    this.layoutMetadataMaster = result;
                })
                .catch(error => {
                    console.log('error layout>>>>>>>>>>>>>>>>>>>' + JSON.stringify(error));
                    this.error = error;                
                    this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
                });
        }

    }

    setLayoutFields(data) {
        var settings = [];
        var settingsMap = data;
        var allBasicInformationFields = [];
        var basicInformationFields = [];
        var productInterestFields = [];        
        var practiceAddressFields = [];
        var productofinterest ;
        var contactFields = [];
        //console.log('settingsMap>>>>>>>>>>>>>>>>>>', settingsMap);
        for (var key in settingsMap) {
            if (key === 'Basic information') {                
                //console.log('settingsMap[key]>>>>>>>>>>>>>>>>>>', JSON.stringify(settingsMap[key]));
               // basicInformationFields = settingsMap[key];
                allBasicInformationFields  = settingsMap[key];
            } else if (key === 'Address') {
                practiceAddressFields = settingsMap[key];
            } else if (key === 'Communication Contact') {
                contactFields = settingsMap[key];
            }
        }

       // this.basicInformationFields = basicInformationFields;
        this.practiceAddressFields = practiceAddressFields;
        this.contactFields = contactFields;

          allBasicInformationFields.forEach(info1 =>{
             if(info1.Field_Name_AGN__c=="Product_Interest_AGN__c"){
                this.productIntSection = true;
                productofinterest = info1;
                productInterestFields.push(info1);
            }
            else{
                basicInformationFields.push(info1);
            }
            console.log('info1>>>>>>>>>>>>>>>>>>', JSON.stringify(info1));
        });

        this.basicInformationFields = basicInformationFields;
        this.productInterestFields =  productInterestFields;
        this.showLoader = false;
        //console.log('basicInformationFields>>>>>>>>>>>>>>>>>>', basicInformationFields);
        //console.log('practiceAddressFields>>>>>>>>>>>>>>>>>>', practiceAddressFields);
        //console.log('contactFields>>>>>>>>>>>>>>>>>>', contactFields);
    }

    handleClick() {


    

    console.log('this.iscaptchavalid1>>>'+ this.iscaptchavalid);
    if(this.source ==="oam"){
      this.template.querySelector('iframe').contentWindow.postMessage({ action: "alohaCallingCAPTCHA" , alohaResponseCAPTCHA : "OK"  }, this.baseurl);                  
    }
    else{
        this.iscaptchavalid = true;
    }
    console.log('this.iscaptchavalid2>>>'+ this.iscaptchavalid);
         this.showLoader = true;
        //this.hidemaindiv = true;
        var allValid = true;
        var isFormatValid = true;
        let address = {
            'sobjectType': 'Allergan_Customer_Address_AGN__c'
        };
        let soldToAddr = this.soldToAddress;
        if(soldToAddr && soldToAddr.Id) address.Id = soldToAddr.Id;
       /* for (let key in soldToAddr) {
            if (soldToAddr.hasOwnProperty(key) && key !== 'sobjectType') {
                address[key] = soldToAddr[key];
            }
        } */
        let registration = {
            'sobjectType': 'Allergan_Customer_Registration_AGN__c'
        };
        if (this.registrationRec && this.registrationRec.Id) registration.Id = this.registrationRec.Id;
        
        /*let regRecord = this.registrationRec;
        for (let key in regRecord) {
            if (regRecord.hasOwnProperty(key) && key !== 'sobjectType') {
                registration[key] = regRecord[key];
            }
        } */
        let crContact = {
            'sobjectType': 'Allergan_Customer_Contact_AGN__c'
        };
        let crContactObj = this.acrContact;
        for (let key in crContactObj) {
            if (crContactObj.hasOwnProperty(key) && key !== 'sobjectType') {
                crContact[key] = crContactObj[key];
            }
        }
        let caseCr = {
            'sobjectType': 'Case'
        };
        let crCaseObj = this.caseRecord;
        for (let key in crCaseObj) {
            if (crCaseObj.hasOwnProperty(key) && key !== 'sobjectType') {
                caseCr[key] = crCaseObj[key];
            }
        }

        var country = this.countryCode;
        registration.Customer_Category_AGN__c = this.selectedCustomerCategory;
        registration.Customer_Sub_Category_AGN__c = this.selectedCustomerSubCategory;
        registration.Country_Code_AGN__c = this.countryCode;
        registration.SAP_Country_Code_AGN__c = this.sapCountryCode;
        var countrysfobj = this.getCountrySFCode(this.sapCountryCode);
        console.log('countrysfobj>>>>>>>>>>>>>>>>>>>>>>>>', countrysfobj);
        if (countrysfobj) {
            registration.Country_AGN__c = countrysfobj.countrySFDCId;
            address.Country_Lookup_AGN__c = countrysfobj.countrySFDCId;
        }
        /* 	CoolSculpting  Start*/
        if (this.accountId) {
            address.Account_AGN__c = this.accountId;
        }
        /* 	CoolSculpting  End*/

        var hasFormatIssues = false;
        this.template.querySelectorAll('c-a-g-n_-g-c-s-p_-common-input-field-component').forEach(element => {
            /* console.log('field>>>>>>>>>>>>' + element.fieldname + '>>>>>>>value>>>>>>>>>>>>>>>>>>>>', element.getUserEnteredInput() + '>>>element.checkValidity()>>>>' + element.checkValidity());
              console.log('required>>>>>>>>>>>>>>', element.required);
              console.log('sobject>>>>>>>>>>>>>>>>>>>>', element.sobjectname);
              console.log('fieldname>>>>>>>>>>>>>>>>>>>>', element.fieldname);  */
            if (element.isActiveField()) {
                isFormatValid = element.isFormatValid();
                if (!isFormatValid) {
                    console.log('Format Error>>>>Setting Message>>>>');
                    element.setCustomErrorMessage(AGN_OAM_Valid_Input); //AGN_CP_FORMAT_INVALID
                    hasFormatIssues = true;
                } else {
                    element.setCustomErrorMessage('');
                }
                if (element.checkValidity() && isFormatValid) {
                    //allValid = true;
                    //console.log("element.getUserEnteredInput()"+element.getUserEnteredInput());
                    let enteredVal = element.getUserEnteredInput();
                    console.log("enteredVal>>>>"+ enteredVal);
                    if (enteredVal) {
                        if (element.sobjectname === 'Allergan_Customer_Registration_AGN__c') {
                            registration[element.fieldname] = enteredVal;
                        } else if (element.sobjectname === 'Allergan_Customer_Address_AGN__c') {
                            address[element.fieldname] = enteredVal;
                        }
                    }

                } else {
                    allValid = false;
                }
            }

        });
        console.log('allValid>>>>>>>>', allValid);
        console.log('Registration>>>>>>>>>>>>>>>', registration);
        console.log('Address>>>>>>>>>>>>>>>>>>>>', address);
        if (allValid && !hasFormatIssues) {
            //this.iscaptchavalid = true;
            if(this.iscaptchavalid)
            {
                //registration.Product_Interest_AGN__c = this.selectedProductInterest;
                console.log('registration.Product_Interest_AGN__c>>>'+registration.Product_Interest_AGN__c); 
            //alert('All form entries look valid. Ready to submit>>>>!');
            console.log('calling isduplicate user>>>>>>>>>>>>>>>');            
            var userLocale = this.language;
            if (this.source === 'cs') { //AGN_OAM_CS
                let contactRecord = {
                    'sobjectType': 'Contact'
                };
                this.invokeCreateCustomerRegistrationForCS(address, registration, this.customerTypeConfig, contactRecord, caseCr, crContact, userLocale, country);
            }
            else{
                isDuplicateUser({
                    email: registration.Email_AGN__c,
                    country: country
                })
                .then(result => {
                    console.log('isDuplicateUser>>>>>>>>>', result);
                    if (result) {
                        //show error
                        this.showLoader = false;
                        this.showToast('Error', AGN_OAM_Apex_DuplicateEmail);
                        this.hidemaindiv = false;
                    } else {

                       // if (this.source === 'oam') {
                            this.invokeCreateAccount(address, registration, country);
                       // } else if (this.source === 'cs') { //AGN_OAM_CS
                        //    let contactRecord = {
                       //         'sobjectType': 'Contact'
                       //     };
                        //    this.invokeCreateCustomerRegistrationForCS(address, registration, this.customerTypeConfig, contactRecord, caseCr, crContact, userLocale, country);
                        //}
                    }

                })
                .catch(error => {
                    console.log(error);
                    this.error = error;
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.error = error;                
                    this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
                });
            }

            

            }
             else{
             this.showLoader = false;
             this.hidemaindiv = false;
             this.error = AGN_OAM_Captcha_Error;                
             this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
             //this.showToast('Error', AGN_OAM_Captcha_Error);

             }
        } else {
            this.showLoader = false;
            this.hidemaindiv = false;
            this.error = AGN_OAM_Invalid_Input;                
            this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
            //this.showToast('Error', AGN_OAM_Invalid_Input);
        }

    }

    invokeCreateAccount(address, registration, country) {
        /* console.log('country>>>>>>>>>>>>>>>', country);
         console.log('address>>>>>>>>>>>>>>>', address);
         console.log('registration>>>>>>>>>>>>>>>', registration); */
        console.log('Account creation');
        createAccount({
                customerAddress: address,
                customer: registration,
                country: country
            })
            .then(result => {
                if (result) {
                    this.account = result;
                    console.log('New Account Created>>>>>>>>>', result);
                    this.invokeCreateContact(address, registration, result, country);
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', 'Unknown Error ');
                }


            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;                         
                this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
                //this.showToast('Error', error);
            });
    }

    invokeCreateContact(address, registration, account, country) {
        console.log('inside invokeCreateContact>>>>>>>', address, registration, account, country);
        createContact({
                customer: registration,
                acc: account,
                country: country
            })
            .then(result => {
                if (result) {
                    this.contact = result;
                    console.log('New Contact Created>>>>>>>>>', result);
                    this.invokecreateCommunityUser(address, result, country, registration);
                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', AGN_OAM_Unknown_Err);
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }

    invokecreateCommunityUser(address, customerContact, country, registration) {
        var userLocale = this.language;
        createCommunityUser({
                customerContactId: customerContact.Id,
                countryCode: country,
                userLocale: userLocale
            })
            .then(result => {
                if (result) {
                    this.contact = result;
                    console.log('New Community User Created>>>>>>>>>', result);
                    this.invokeCreateCustomerRegistration(address, registration, this.customerTypeConfig, customerContact, userLocale, country);

                    //this.invokeCreateOktaUserSendLink(registration, customerContact, userLocale, country);

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', AGN_OAM_Unknown_Err);
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }

    invokeCreateCustomerRegistration(address, registration, configList, customerContact, userLocale, country) {

        console.log('**********New Customer Registration************');
        /* console.log('customerAddress>>>>>>>>>>>>>>>>', address);
         console.log('configList>>>>>>>>>>>>>>>>', configList);
         console.log('customerContact>>>>>>>>>>>>>>>>', customerContact);
         console.log('userLocale>>>>>>>>>>>>>>>>', userLocale); */
        console.log('Coountry::::: ' + country);
        createNewCustomerRegistration({
                customer: registration,
                customerAddress: address,
                configList: configList,
                customerContact: customerContact,
                userLocale: userLocale
            })
            .then(result => {
                if (result) {
                    console.log('New Customer Registration Created>>>>>>>>>', result);
                    this.invokeCreateOktaUserSendLink(registration, customerContact, userLocale, country);

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', error);
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    invokeCreateCustomerRegistrationForCS(address, registration, configList, customerContact, casenewCr, acrContact,  userLocale, country) {

        console.log('**********New Customer Registration CS************');
        /* console.log('customerAddress>>>>>>>>>>>>>>>>', address);
         console.log('configList>>>>>>>>>>>>>>>>', configList);
         console.log('customerContact>>>>>>>>>>>>>>>>', customerContact);*/
        console.log('userLocale>>>>>>>>>>>>>>>>', userLocale);
        createNewCustomerRegistrationCS({
                customer: registration,
                customerAddress: address,
                configList: configList,
                customerContact: customerContact,
                caseCr: casenewCr,
                acrContact: acrContact,
                userLocale: country
            })
            .then(result => {
                if (result) {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    console.log('New Customer Registration Created>>>>>>>>>', result);
                    this.RegistrationStepNo = '2';
                    this.caseId = result;
                    /*const regStepNoEvent = new FlowAttributeChangeEvent('RegistrationStepNo', this.RegistrationStepNo);
                    const caseIdEvent = new FlowAttributeChangeEvent('caseId', this.caseId);

                    this.dispatchEvent(regStepNoEvent);
                    this.dispatchEvent(caseIdEvent);

                    const nextNavigationEvent = new FlowNavigationNextEvent();
                    this.dispatchEvent(nextNavigationEvent); */
                    this.nextOrPreviousActionEvent(result, '2');

                } else {
                    this.showLoader = false;
                    this.hidemaindiv = false;
                    this.showToast('Error', AGN_OAM_Unknown_Err);
                }

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }
    nextOrPreviousActionEvent(caseId, stepNo) {
         const selectEvent = new CustomEvent('stepinfoevent',  {
            detail: {
                caseId: caseId,
                stepNo: stepNo
            }           
         });
         this.dispatchEvent(selectEvent);
     }
    invokeCreateOktaUserSendLink(registration, customerContact, userLocale, country) {

        console.log('**********New Okta User Creation************');
        /*console.log('registration>>>>>>>>>>>>>>>>', registration);
        console.log('customerContact>>>>>>>>>>>>>>>>', customerContact);
        console.log('userLocale>>>>>>>>>>>>>>>>', userLocale);
        console.log('country>>>>>>>>>>>>>>>>', country); */
        createOktaUserSendLink({
                customer: registration,
                customerContact: customerContact,
                userLocale: userLocale,
                country: country
            })
            .then(result => {
                console.log('New Okta User Created>>>>>>>>>', result);
                switch (result) {
                    case 'SUCCESS':
                        break;
                    case 'FAILURE':
                        this.showToast('Error', AGN_OAM_Contact_Service);
                        break;
                    case 'DEPROVISIONED':
                        this.showToast('Error', AGN_OAM_Inactive_State);
                        break;
                    default:
                        this.showToast('Error', AGN_OAM_Unknown_Err);
                        break;
                }
                this.showLoader = false;
                this.hidemaindiv = false;
                this.isCompleted = true;
                this.hidemaindiv = false;

            })
            .catch(error => {
                console.log(error);
                this.error = error;
                this.showLoader = false;
                this.hidemaindiv = false;
                this.showToast('Error', error);
            });
    }

    getCountrySFCode(country) {
        var countryobj;
        this.picklistCountryOptions.forEach(function (currRow) {
            if (currRow.Alpha_2_Code_vod__c.toUpperCase() === country.toUpperCase()) {
                countryobj = {
                    'countrySFDCId': currRow.Id,
                    'countryName': currRow.AGN_Country_Name__c
                };
            }
        });
        return countryobj;
    }

    showToast(title, message) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: "error"
        });
        this.dispatchEvent(event);
    }

    showToastSticky(title, message) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: "error",
            mode: "sticky"
        });
        this.dispatchEvent(event);
    }
    checkboxHandler(event) {
        console.log('event.target.checked>>>>>>>>>>>>>', event.target.checked);
        let fieldname = event.target.name;
        let checked = event.target.checked;
        if (fieldname === 'termsncondns') {
            if (checked) {
                this.disableSubmitBtn = false;
            } else {
                this.disableSubmitBtn = true;
            }
        }
    }

    handleControllingFieldEvent(event) {
        const eventParemeters = event.detail;

        const controllingFieldSobjectName = eventParemeters.controllingFieldSobjectName;
        console.log("controllingFieldSobjectName -> " + controllingFieldSobjectName);
        const controllingFieldName = eventParemeters.controllingFieldName;
        console.log("controllingFieldName -> " + controllingFieldName);
        const controllingFieldSelectedValue = eventParemeters.controllingFieldSelectedValue;
        console.log("controllingFieldSelectedValue -> " + controllingFieldSelectedValue);

        let dependentFieldList = [];
        //console.log("layoutMetadataMaster -> " + JSON.stringify(this.layoutMetadataMaster));
        //finding dependent field list based upon event received with parameters
        //console.log("layoutMetadataMaster Keys -> " +  Object.keys(this.layoutMetadataMaster));
        var itr = 1;
        Object.keys(this.layoutMetadataMaster).forEach(key => {
            console.log('layoutMetadataMaster[key]>>' + JSON.stringify(this.layoutMetadataMaster[key]));
            let dependentField = this.layoutMetadataMaster[key].find(layout => {
                console.log('layout>>' + JSON.stringify(layout));
                if (layout.Controlling_Field_AGN__c == controllingFieldName &&
                    layout.Controlling_Field_SObject_Name_AGN__c == controllingFieldSobjectName) {
                    console.log('itr>>' + itr);
                    itr++;
                    dependentFieldList.push(layout);
                    //return layout;

                }
            });
            /*if (dependentField) {
                dependentFieldList.push(dependentField);
            }*/
        });

        if (dependentFieldList.length > 0) {
            console.log('dependentFieldList>>>' + JSON.stringify(dependentFieldList));
            dependentFieldList.forEach(field => {
                this.template.querySelectorAll('c-a-g-n_-g-c-s-p_-common-input-field-component').forEach(element => {
                    if (element.fieldname === field.Field_Name_AGN__c &&
                        element.sobjectname === field.SObject_Name_AGN__c) {
                        console.log('Checking the dependent List>>');
                        element.removeInputValue();
                        if (field.Dependent_Field_Show_Criteria_AGN__c.includes(controllingFieldSelectedValue)) {
                            element.showCmp();
                            console.log('met conditions>>');
                            this.showtest = true;
                            return;
                        } else {
                            element.hideCmp();
                            this.showtest = false;
                            return;
                        }
                    }
                });
            });
        }
    }

    handleChk(event){

        const eventParemeters = event.detail;
        console.log('Event captured in parent>>>'+eventParemeters.selectedVal);
        console.log('Event captured in parent2>>>'+eventParemeters.isSelected);
        console.log('Event captured in parent3>>>'+this.selectedProductInterest.indexOf(eventParemeters.selectedVal));
        if(eventParemeters.isSelected==true && this.selectedProductInterest.indexOf(eventParemeters.selectedVal) ==-1){
            console.log('true>>'); 
            this.selectedProductInterest.push(eventParemeters.selectedVal);
        }
        if(eventParemeters.isSelected==false){
            console.log('false>>'); 
            this.selectedProductInterest.pop(this.selectedProductInterest.indexOf(eventParemeters.selectedVal));
        }       
        console.log('selectedProductInterest>>>'+this.selectedProductInterest);
    }
}