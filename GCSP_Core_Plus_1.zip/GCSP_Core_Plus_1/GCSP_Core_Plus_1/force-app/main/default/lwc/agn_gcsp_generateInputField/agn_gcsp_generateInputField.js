import { LightningElement , api , wire , track } from 'lwc';

import getFieldMetadata from '@salesforce/apex/AGN_GCSP_MetadataController.getFieldMetadata';
import getAddressDetails from '@salesforce/apex/AGN_GCSP_PortalCustomerRegUtils.fetchAddress';

import AGN_OAM_Last_Name from '@salesforce/label/c.AGN_OAM_Last_Name';
import AGN_OAM_First_Name from '@salesforce/label/c.AGN_OAM_First_Name';
import AGN_OAM_Body_DOB from '@salesforce/label/c.AGN_OAM_Body_DOB';
import AGN_OAM_Body_Gender from '@salesforce/label/c.AGN_OAM_Body_Gender';
import AGN_OAM_Body_Phone from '@salesforce/label/c.AGN_OAM_Body_Phone';
import AGN_OAM_Phone from '@salesforce/label/c.AGN_OAM_Phone';
import AGN_OAM_City from '@salesforce/label/c.AGN_OAM_City';
import AGN_OAM_State from '@salesforce/label/c.AGN_OAM_State';
import AGN_OAM_Company_Name from '@salesforce/label/c.AGN_OAM_Company_Name';
import AGN_OAM_Department_Name from '@salesforce/label/c.AGN_OAM_Department_Name';
import AGN_OAM_Address_Line_1 from '@salesforce/label/c.AGN_OAM_Address_Line_1';
import AGN_OAM_Salutation from '@salesforce/label/c.AGN_OAM_Salutation';
import AGN_OAM_Body_Surname from '@salesforce/label/c.AGN_OAM_Body_Surname';

import AGN_OAM_Body_PurposeOfBusiness from '@salesforce/label/c.AGN_OAM_Body_PurposeOfBusiness';
import AGN_OAM_Body_PostalCode from '@salesforce/label/c.AGN_OAM_Body_PostalCode';
import AGN_OAM_Body_Street from '@salesforce/label/c.AGN_OAM_Body_Street';
import AGN_OAM_Body_Number from '@salesforce/label/c.AGN_OAM_Body_Number';
import AGN_OAM_Body_Address_Line_2 from '@salesforce/label/c.AGN_OAM_Body_Address_Line_2';
import AGN_OAM_Body_Address_Line_3 from '@salesforce/label/c.AGN_OAM_Body_Address_Line_3';
import AGN_OAM_Body_City from '@salesforce/label/c.AGN_OAM_Body_City';
import AGN_OAM_Body_County from '@salesforce/label/c.AGN_OAM_Body_County';
import AGN_OAM_Body_Mobile from '@salesforce/label/c.AGN_OAM_Body_Mobile';
import AGN_OAM_Body_Email from '@salesforce/label/c.AGN_OAM_Body_Email';
import AGN_OAM_Body_Email2 from '@salesforce/label/c.AGN_OAM_Body_Email2';
import AGN_OAM_Body_Title from '@salesforce/label/c.AGN_OAM_Body_Title';
import AGN_OAM_Body_Name from '@salesforce/label/c.AGN_OAM_Body_Name';
import AGN_OAM_Body_Preferred from '@salesforce/label/c.AGN_OAM_Body_Preferred';

export default class Agn_gcsp_generateInputField extends LightningElement {

    @api country;
    @api address;
    @api sobjectname;
    @api fieldname;
    @api fieldValue; 
    @api required;
    @api labelVal;
    @api regex;
    @api disabled = false;
    @api customlabel;
    @track metadataval;
    @track displayType;
    @track privateRecord;
    @track picklistOptions;
    @track labelMap = new Map();
    @track isZipcode = false;
    @track isBr = false;
    @track newValue; 
    @track showhide;

    @track isPhone = false;
    @track isString = false;
    @track isUrl = false;
    @track isTextArea = false;
    @track isPercent = false;
    @track isPicklist = false;
    @track isNumber = false;
    @track isDate = false;
    @track isDateTime = false;
    @track isCurrency = false;
    @track isBoolean = false;
    @api instancetype;
    @api objecttype;
    @api index;
    @api isChanged = false;
    @api applicableforregistration;
    @api rendered = false;
    @api objectfieldtype; //field type of dummy object
    @api iscontrollingfield = false;
    @api dependentfieldsproperty;    
    @api step = '';
    // eslint-disable-next-line @lwc/lwc/valid-api
    @api
    get record() {
        return this.privateRecord;
    }

    set record(value) {
        if(value){
            this.privateRecord = value;
            var rec = value;
            //console.log('record>>>>>>>>>>>>>>>',rec);
            var fldname = this.fieldname;
            //console.log('fldname>>>>>>>>>>>>>>>',fldname);
            var fieldVal = rec[fldname];
            //console.log('fieldVal>>>>>>>>>>>>>>>',fieldVal);
            if(fieldVal){
                this.fieldValue = fieldVal;
            }
            
        }
    }

    label = {
        AGN_OAM_Last_Name,
        AGN_OAM_First_Name,
        AGN_OAM_Body_DOB,
        AGN_OAM_Body_Gender,
        AGN_OAM_Body_Phone,
        AGN_OAM_Body_Name,
        AGN_OAM_Body_Surname,
        AGN_OAM_Phone,
        AGN_OAM_City, 
        AGN_OAM_State, 
        AGN_OAM_Company_Name,
        AGN_OAM_Address_Line_1, 
        AGN_OAM_Department_Name,    
        AGN_OAM_Salutation,
        AGN_OAM_Body_PurposeOfBusiness,
        AGN_OAM_Body_PostalCode,
        AGN_OAM_Body_Street,
        AGN_OAM_Body_Number,
        AGN_OAM_Body_Address_Line_2,
        AGN_OAM_Body_Address_Line_3,
        AGN_OAM_Body_City,
        AGN_OAM_Body_County,
        AGN_OAM_Body_Mobile,
        AGN_OAM_Body_Email,
        AGN_OAM_Body_Email2,
        AGN_OAM_Body_Preferred,
        AGN_OAM_Body_Title

    };

    get inputClass(){
        var inpclass = '';
        var instancetype = this.instancetype;
        //console.log('instancetype>>>>>>>>>>>>>>>>>>',instancetype);
        if(instancetype && instancetype === 'new'){
            inpclass = 'commoninputcmp newinstance';
        }else{
            inpclass = 'commoninputcmp';
        }
        //console.log('inpclass>>>>>>>>>>>>>>>>>>',inpclass);
        return inpclass;
        //return isnew ? 'commoninputcmp newinstance' : 'commoninputcmp';
    }

    @api showCmp() {
        this.rendered = true;
        this.showhide = 'slds-show';
    }

    @api hideCmp() {
        this.rendered = false;
        this.showhide = 'slds-hide';
    }

    @api isCmpHidden() {
        return this.rendered;
    }

    connectedCallback() {
        
        // initialize component
       // console.log('***********inside constructor****************',this.record);
       if(this.country=='BR' && this.fieldname=='Zip_AGN__c'){
        this.isBr = true;
       }
       if(this.step && this.step === '4' 
          && this.objecttype === 'soldto' 
          && this.instancetype === 'old'
          && this.fieldname === 'VAT_Number_AGN__c'){
           this.required = false; //Making this false in soldto level. Already this field is available in step3
       }
       console.log('fieldname>>'+this.fieldname+' rendered>>'+this.rendered);
       if(this.fieldname === 'City_AGN__c'){
         console.log('this.City_AGN__c>>'+this.rendered);
       }

       if(this.applicableforregistration === false){
           this.disabled = true;
       }

        console.log(' this.rendered 112--> ' + this.rendered);
        
        if(this.rendered === undefined || this.rendered == true){
            console.log('entering 1>>>');
            this.rendered = true;
            this.showhide = 'slds-show';
            console.log('showhide>>>'+this.showhide);
        }
        else if(this.rendered == false){
            console.log('entering 2>>>');
            this.rendered = false;
            this.showhide = 'slds-hide';
            console.log('showhide>>>'+this.showhide);
        }

        //undefined or null or empty string then its has dummy field, render dummy field
        if (!this.sobjectname) {
            this.fieldTypeAssignment(this.objectfieldtype);
        }
        
        //create label map
        var lbMap = new Map(); 
        lbMap.set('AGN_OAM_Last_Name' , AGN_OAM_Last_Name);
        lbMap.set('AGN_OAM_First_Name' , AGN_OAM_First_Name);
        lbMap.set('AGN_OAM_Phone' , AGN_OAM_Phone);
        lbMap.set('AGN_OAM_Body_DOB' , AGN_OAM_Body_DOB);
        lbMap.set('AGN_OAM_Body_Gender' , AGN_OAM_Body_Gender);
        lbMap.set('AGN_OAM_Body_Phone' , AGN_OAM_Body_Phone);
        lbMap.set('AGN_OAM_City' , AGN_OAM_City);
        lbMap.set('AGN_OAM_Salutation' , AGN_OAM_Salutation);
        lbMap.set('AGN_OAM_State' , AGN_OAM_State);
        lbMap.set('AGN_OAM_Company_Name' , AGN_OAM_Company_Name);
        lbMap.set('AGN_OAM_Department_Name' , AGN_OAM_Department_Name);
        lbMap.set('AGN_OAM_Address_Line_1' , AGN_OAM_Address_Line_1);

        lbMap.set('AGN_OAM_Body_PurposeOfBusiness' , AGN_OAM_Body_PurposeOfBusiness);
        lbMap.set('AGN_OAM_Body_PostalCode' ,AGN_OAM_Body_PostalCode);
        lbMap.set('AGN_OAM_Body_Street' , AGN_OAM_Body_Street);
        lbMap.set('AGN_OAM_Body_Number' , AGN_OAM_Body_Number);
        lbMap.set('AGN_OAM_Body_Address_Line_2' , AGN_OAM_Body_Address_Line_2);
        lbMap.set('AGN_OAM_Body_Address_Line_3' , AGN_OAM_Body_Address_Line_3);
        lbMap.set('AGN_OAM_Body_City' , AGN_OAM_Body_City);
        lbMap.set('AGN_OAM_Body_County' , AGN_OAM_Body_County);
        lbMap.set('AGN_OAM_Body_Mobile' , AGN_OAM_Body_Mobile);
        lbMap.set('AGN_OAM_Body_Email' , AGN_OAM_Body_Email);
        lbMap.set('AGN_OAM_Body_Email2' , AGN_OAM_Body_Email2);
        lbMap.set('AGN_OAM_Body_Preferred' , AGN_OAM_Body_Preferred);
        lbMap.set('AGN_OAM_Body_Name' , AGN_OAM_Body_Name);
        lbMap.set('AGN_OAM_Body_Surname' , AGN_OAM_Body_Surname);
        lbMap.set('AGN_OAM_Body_Title' , AGN_OAM_Body_Title);
        
        
        //console.log('Map>>>>>>>>>>>>>>>>>>>>>>>>>>>>',lbMap);
        //console.log('customlabel>>>>>>>>>>>>>>>>',this.customlabel);
        var labvalue = lbMap.get(this.customlabel); // set label value
        //console.log('labval>>>>>>>>>>>>>>>>>>>',labvalue);
        this.labelVal = labvalue;
    }

    fieldTypeAssignment(objectfieldtype){
        switch (objectfieldtype) {
            case 'STRING':
                this.isString = true;
                break;
            case 'PHONE':
                this.isPhone = true;
                break;
            case 'URL':
                this.isUrl = true;
                break;
            case 'TEXTAREA':
                this.isTextArea = true;
                break;
            case 'PERCENT':
                this.isPercent = true;
                break;
            case 'EMAIL':
                this.isString = true;
                break;
            case 'PICKLIST':
                this.isPicklist = true;
                //this.isString = true;
                break;
            case 'DOUBLE':
                this.isNumber = true;
                break;
            case 'INTEGER':
                this.isNumber = true;
                break;
            case 'DATE':
                this.isDate = true;
                break;
            case 'DATETIME':
                this.isDateTime = true;
                break;
            case 'CURRENCY':
                this.isCurrency = true;
                break;
            case 'BOOLEAN':
                this.isBoolean = true;
                break;
            default: this.isString = true;
                break;
        }
    }

    handleBlur(){
        var inputCmp = this.template.querySelector(".commoninputcmp");
        if(this.isFormatValid()){
            inputCmp.setCustomValidity('');
        }
    }

    handleChange(event){
       let newval;
       //this.newValue = newval;

        if (event.target.type === 'checkbox' ||
            event.target.type === 'checkbox-button' ||
            event.target.type === 'toggle') {
                
            newval = event.target.checked;
        } else {
            newval = event.target.value;
        }

       if(!newval && !this.fieldValue){
            this.isChanged = false;
       }
       else{
            if(newval === this.fieldValue){
                this.isChanged = false;
            }else{
                this.isChanged = true;
            }
       }
       //alert(this.isBr);
       if(this.isBr && newval.length>=8 ){
        this.newValue = newval;
        var zipCodeEvent = new CustomEvent('zipcodechange',{detail : this.newValue});
        this.dispatchEvent(zipCodeEvent);
        //alert(newval);
        //getAddress(this.newValue);
       }

       if (this.iscontrollingfield) {

        var controllingFieldSobjectName = this.sobjectname;
        var controllingFieldName = this.fieldname;
        var controllingFieldSelectedValue = newval;

        var selectedEvent = new CustomEvent('controllingfieldevent',
            {
                detail:
                {
                    controllingFieldSobjectName: controllingFieldSobjectName,
                    controllingFieldName: controllingFieldName,
                    controllingFieldSelectedValue: controllingFieldSelectedValue
                }
            });
        // Dispatches the event.
        console.log('custom event controllingfieldevent fired');
        this.dispatchEvent(selectedEvent);
    }
    }

    @api removeInputValue() {
        var inputCmp = this.template.querySelector(".commoninputcmp");
        //inputCmp.setCustomValidity('');
        inputCmp.value = '';
    }
    @api getUserEnteredInput() {
        //console.log('inside getUserEnteredInput>>>>>>>>>>>>>>>>>>>');
       // console.log('this.template.querySelector(".commoninputcmp")>>>>>>>>>>>>',this.template.querySelector(".commoninputcmp"));
        var inputCmp = this.template.querySelector(".commoninputcmp");
       // console.log('input val>>>>>>>>>>>>',inputCmp);
        var value = inputCmp.value;
        return value;
    }

    @api isFormatValid(){
        var formatValid = true;
        var value =  this.getUserEnteredInput();
        var regex = this.regex;
        console.log('regex>>',regex);
        if(value && regex){
            if(value.match(regex)){
                formatValid =  true;
            }else{
                formatValid =  false;
            }
        }
        return formatValid;
    }

    @api setCustomErrorMessage(errorMsg){
        var inputCmp = this.template.querySelector(".commoninputcmp");
        inputCmp.setCustomValidity(errorMsg);
    }

    @api checkValidity() {
        var inputCmp = this.template.querySelector(".commoninputcmp");
        return inputCmp.reportValidity();
    }
   
    @wire(getFieldMetadata, { sobjectName: '$sobjectname' , fieldName : '$fieldname' })
    wiredmetadata({ error, data }) {
        if (data) {
            //alert('dddddd');
            // eslint-disable-next-line no-console
            if(data){
               // console.log('meta data>>>>>>>>>>>>>>>>>>>>>>>>>>>',data);
                if(this.displayType === undefined) {
                    this.displayType = data.displayType;
                }
                /*if(component.get('v.disabled') === undefined) {
                    component.set('v.disabled', fieldMetadata.isUpdateable == false);
                }*/
                if(this.required === undefined) {
                    var isUpdateableRequired = data.isUpdateable && data.required;
                    var isUpdateableNameField = data.isUpdateable && data.isNameField;
                    this.required = isUpdateableRequired || isUpdateableNameField;
                }
                
                //this.labelVal = data.label;
                //console.log('label map>>>>>>>>>>>',this.labelMap);
                //this.labelVal = this.labelMap.get(this.customlabel);
                //console.log('labelVal>>>>>>>>>>>>>>',this.labelVal);
                switch(data.displayType){
                    case 'STRING' : 
                        this.isString = true;
                        break;
                    case 'PHONE' : 
                        this.isPhone = true;
                        break;
                    case 'URL' : 
                        this.isUrl = true;
                        break;
                    case 'TEXTAREA' : 
                        this.isTextArea = true;
                        break;
                    case 'PERCENT' : 
                        this.isPercent = true;
                        break;
                    case 'EMAIL' : 
                        this.isString = true;
                        break;
                    case 'PICKLIST' : 
                        this.isPicklist = true;
                        break;
                    case 'DOUBLE' : 
                        this.isNumber = true;
                        break; 
                    case 'INTEGER' : 
                        this.isNumber = true;
                        break;    
                    case 'DATE' : 
                        this.isDate = true;
                        break;
                    case 'DATETIME' : 
                        this.isDateTime = true;
                        break;
                    case 'CURRENCY' : 
                        this.isCurrency = true;
                        break;
                    case 'BOOLEAN' : 
                        this.isBoolean = true;
                        break;
                    default : this.isString = true;
                        break;
                }
                if(data.displayType === 'PICKLIST' && data.picklistOptions){
                    var country = this.country;
                    var sobjectname = this.sobjectname;
                    var fieldname = this.fieldname;

                   // console.log('country >>',country);
                   // console.log('sobjectname >>',sobjectname,);
                   // console.log('fieldname >>',fieldname);
                    //var ops = data.picklistOptions;
                   // this.setPicklistOptions(ops , country , sobjectname , fieldname);
                    var picklistOptionArr = [];
                    if(country === 'IT' || country === 'GB' ){
                        var picklistOptions = data.picklistOptions;
                        //state
                        if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' 
                            && fieldname.toUpperCase() === 'STATE_AGN__C'){
                            for(var i in picklistOptions){                               
                                if(picklistOptions[i].value.startsWith(country)){
                                    picklistOptionArr.push(picklistOptions[i]);
                                }
                                    
                                //console.log(JSON.stringify(picklistOptions[i]));
                            }
                        }else if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' 
                                 && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                            for(var i in picklistOptions){
                                if(picklistOptions[i].value !=='Sister' 
                                   && picklistOptions[i].value !=='Nurse' 
                                   && picklistOptions[i].value !=='Pr.' 
                                   && picklistOptions[i].value !=='Dra.'){
                                    picklistOptionArr.push(picklistOptions[i]);
                                }
                            }
                        }else if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' 
                                && fieldname.toUpperCase() === 'COUNTRY_AGN__C'){
                                    picklistOptionArr.push(picklistOptions[0]); //added default blank                        
                                    for(var i in picklistOptions){                             
                                                    if(picklistOptions[i].value === 'San Marino' || picklistOptions[i].value === 'Vatican' || picklistOptions[i].value === 'Italy'){                              
                                                        
                                                        picklistOptionArr.push(picklistOptions[i]);
                                                        //console.log(JSON.stringify(picklistOptions[i]));   
                                                    }                           
                                    }
                                    
                        }else{
                            picklistOptionArr = picklistOptions;
                        }
                        console.log('picklistOptionArr after processing>>>>>>',picklistOptionArr);
                        this.picklistOptions = picklistOptionArr;
                    }
                    if(country === 'BR'){
                        var picklistOptions = data.picklistOptions;
                        //state
                        if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' 
                            && fieldname.toUpperCase() === 'STATE_AGN__C'){
                            for(var i in picklistOptions){                               
                                if(picklistOptions[i].value.startsWith(country)){
                                    picklistOptionArr.push(picklistOptions[i]);
                                }
                                    
                                //console.log(JSON.stringify(picklistOptions[i]));
                            }
                        }else if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' 
                                 && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                            for(var i in picklistOptions){
                                if(picklistOptions[i].value !=='Sister' 
                                   && picklistOptions[i].value !=='Nurse' 
                                   && picklistOptions[i].value !=='Pr.' 
                                   && picklistOptions[i].value !=='Dra.'){
                                    picklistOptionArr.push(picklistOptions[i]);
                                }
                            }
                        }else if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' 
                                && fieldname.toUpperCase() === 'COUNTRY_AGN__C'){
                                    picklistOptionArr.push(picklistOptions[0]); //added default blank                        
                                    for(var i in picklistOptions){                             
                                                    if(picklistOptions[i].value === 'San Marino' || picklistOptions[i].value === 'Vatican' || picklistOptions[i].value === 'Italy'){                              
                                                        
                                                        picklistOptionArr.push(picklistOptions[i]);
                                                        //console.log(JSON.stringify(picklistOptions[i]));   
                                                    }                           
                                    }
                                    
                        }else{
                            picklistOptionArr = picklistOptions;
                        }
                        //console.log('picklistOptionArr after processing>>>>>>',picklistOptionArr);
                        this.picklistOptions = picklistOptionArr;
                    }
                    
                    
                }
            }
            //this.error = undefined;
        } else if (error) {
            //this.error = error;
            // eslint-disable-next-line no-console
            //console.log('error>>>>>>>>>>>>>>',error);
            this.metadataval = undefined;
        }
    }

    setPicklistOptions(picklistOptions , country , sobjectname , fieldname){
        //console.log('picklistOptions>>>>>>>>>>>>>>>>>>>>>>>>>>>>',picklistOptions);
       // console.log('country>>>>>>>>>>>>>>>>>>>>>>>>>>>>',country);
        //console.log('sobjectname>>>>>>>>>>>>>>>>>>>>>>>>>>>>',sobjectname);
        //console.log('fieldname>>>>>>>>>>>>>>>>>>>>>>>>>>>>',fieldname);
        if(country !== 'IT'){
            var picklistOptionArr = [];
            for(var i in picklistOptions){
                if(picklistOptions[i].value.toUpperCase() ==='9' || picklistOptions[i].value.toUpperCase() ==='0'){
                   picklistOptionArr.push(picklistOptions[i]);                                    
                }
            }
            picklistOptions = picklistOptionArr;
        }
        
        if(sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' && fieldname.toUpperCase() === 'STATE_AGN__C'){
                                
                                var picklistOptionArr = [];
                                picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                //console.log('State with countr---->'  + country);
                                
                                if(country === 'CA'){
                                    for(var i in picklistOptions){
                                        if(picklistOptions[i].value.startsWith(country+'-'))
                                            picklistOptionArr.push(picklistOptions[i]);
                                    }
                                    picklistOptions = picklistOptionArr;
                                }else if(country === 'AU' || country === 'NZ' || country ==='AN'){
                                    for(var i in picklistOptions){
                                        if(picklistOptions[i].value.startsWith(country+'-'))
                                            picklistOptionArr.push(picklistOptions[i]);
                                    }
                                    picklistOptions = picklistOptionArr;
                                }else{
                                    for(var i in picklistOptions){                               
                                        if(picklistOptions[i].value.startsWith(country))
                                            picklistOptionArr.push(picklistOptions[i]);
                                        //console.log(JSON.stringify(picklistOptions[i]));
                                    }
                                    picklistOptions = picklistOptionArr;
                                    // console.log('StateValues>>>'+JSON.stringify(picklistOptionArr));
                                }
        }
        //Removing Miss and MS Values for Country Germany
        if(country === 'DE' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                                var picklistOptionArr = [];
                                //picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                for(var i in picklistOptions){
                                    if(picklistOptions[i].value !== 'Ms.' && picklistOptions[i].value !== 'Miss' && picklistOptions[i].value !== 'Pr.' && picklistOptions[i].value !== 'Dra.'){
                                        
                                        picklistOptionArr.push(picklistOptions[i]);
                                        // console.log(JSON.stringify(picklistOptions[i]));
                                        
                                    }
                                }
                                picklistOptions = picklistOptionArr;
        }
        //Removing Sister and Nurse,Pr Values for Country Italy
        if(country === 'IT' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                                var picklistOptionArr = [];
                                //picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                for(var i in picklistOptions){
                                    if(picklistOptions[i].value !=='Sister' && picklistOptions[i].value !=='Nurse' && picklistOptions[i].value !=='Pr.' && picklistOptions[i].value !=='Dra.'){
                                        
                                        picklistOptionArr.push(picklistOptions[i]);
                                        // console.log(JSON.stringify(picklistOptions[i]));
                                        
                                    }
                                }
                                picklistOptions = picklistOptionArr;
        }
                            //Removing Nurse Values for Country Canada
        if(country === 'CA' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' 
        && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                                var picklistOptionArr = [];
                                //picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                for(var i in picklistOptions){
                                    if(picklistOptions[i].value !=='Nurse'){
                                        
                                        picklistOptionArr.push(picklistOptions[i]);
                                        // console.log(JSON.stringify(picklistOptions[i]));
                                    }
                                }
                                picklistOptions = picklistOptionArr;
        }
                            
                            //Removing Sister and Nurse,Miss,Ms. Values for Country FR
        if(country === 'FR' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' 
        && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                                var picklistOptionArr = [];
                                //picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                for(var i in picklistOptions){
                                    if(picklistOptions[i].value !== 'Sister' && picklistOptions[i].value !== 'Nurse' && picklistOptions[i].value !=='Miss'
                                       && picklistOptions[i].value !== 'Ms.' && picklistOptions[i].value !== 'Dra.'){
                                        
                                        picklistOptionArr.push(picklistOptions[i]);
                                        // console.log(JSON.stringify(picklistOptions[i]));
                                    }
                                }
                                picklistOptions = picklistOptionArr;
        }
                            //Removing Sister and Nurse,Miss,Pr Values for Country ES
        if(country === 'ES' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' 
        && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
                                var picklistOptionArr = [];
                                //picklistOptionArr.push(picklistOptions[0]); //added default blank
                                
                                for(var i in picklistOptions){
                                    if(picklistOptions[i].value !== 'Sister' && picklistOptions[i].value !== 'Nurse' && picklistOptions[i].value !== 'Miss' && picklistOptions[i].value !== 'Pr.'){
                                        
                                        picklistOptionArr.push(picklistOptions[i]);
                                        // console.log(JSON.stringify(picklistOptions[i]));
                                    }
                                }
                                picklistOptions = picklistOptionArr;
        }
        if(country === 'IT' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_ADDRESS_AGN__C' 
        && fieldname.toUpperCase() === 'COUNTRY_AGN__C'){
                                
                                var picklistOptionArr = [];
                                picklistOptionArr.push(picklistOptions[0]); //added default blank                        
                                for(var i in picklistOptions){                             
                                    if(picklistOptions[i].value === 'San Marino' || picklistOptions[i].value === 'Vatican' || picklistOptions[i].value === 'Italy'){                              
                                        picklistOptionArr.push(picklistOptions[i]);
                                        //console.log(JSON.stringify(picklistOptions[i]));   
                                    }                           
                                }
                                picklistOptions = picklistOptionArr;
        }
        if(country === 'BR' && sobjectname.toUpperCase() === 'ALLERGAN_CUSTOMER_REGISTRATION_AGN__C' && fieldname.toUpperCase() === 'SALUTATION_AGN__C'){
            var picklistOptionArr = [];
            //picklistOptionArr.push(picklistOptions[0]); //added default blank
            
            for(var i in picklistOptions){
                if(picklistOptions[i].value !== 'Ms.' && picklistOptions[i].value !== 'Miss' && picklistOptions[i].value !== 'Pr.' && picklistOptions[i].value !== 'Dra.'){
                    
                    picklistOptionArr.push(picklistOptions[i]);
                    // console.log(JSON.stringify(picklistOptions[i]));
                    
                }
            }
            picklistOptions = picklistOptionArr;
}
        //console.log('final options000>>>>>>>>>>>>>>>>>',picklistOptions);
        picklistOptions.sort((a, b) => (a.value > b.value) ? 1 : -1);
        //console.log('final options>>>>>>>>>>>>>>>>>',picklistOptions);
        this.picklistOptions = picklistOptions;
    }

    @api setInputValue(newVal) {

        var inputCmp = this.template.querySelector(".commoninputcmp");
        this.fieldValue = newVal;
    }




}