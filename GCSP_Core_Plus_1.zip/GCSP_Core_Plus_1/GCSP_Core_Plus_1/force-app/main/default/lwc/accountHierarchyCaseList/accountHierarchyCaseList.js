import { api, LightningElement } from 'lwc';

// Apex Method to fetch Case List
import getCaseList from '@salesforce/apex/AGN_Account_Hierarchy_Helper.getCaseList';

// List of fields to be displayed in the datatable
const COLUMNS = [
    { label: 'CaseNumber', fieldName: 'caseUrl', type:'url',
        typeAttributes: {
            label: { 
                fieldName: 'CaseNumber' 
            },
            target : '_blank'
        } 
    },
    { label: 'Created Date', fieldName: 'CreatedDate', type: 'date' },
    { label: 'Sub Status', fieldName: 'Sub_Status_AGN__c', type: 'string' },
    { label: 'Type', fieldName: 'Type', type: 'string' },
    { label: 'Current Owner', fieldName: 'ownerName', type: 'string' },
];

// Message to display if no case records returned
const NORECORDS = 'No cases associated with this account';
// Creating Base URL
const ORGURL = 'https://allerganemea--hcoeudev.my.salesforce.com/';

export default class AccountHierarchyCaseList extends LightningElement {
    
    // Public variable to accept the Id of the account for which information is to be displayed
    @api accountId;
    // Reactive variable to accept list of cases from imperative apex call, and display data
    record;
    // Reactive variable to store if number of cases returned is greater than 0
    caseReturned;
    // List of columns to be displayed in datatble
    columns = COLUMNS;
    // This variable set to false when component is inserted and to true when apex promise is completed
    // Controls spinner at component load  
    rendered;
    // Map of Labels
    label = {
        noRecords : NORECORDS
    };

    // Action to be executed on insertion of the component
    connectedCallback() {
        this.rendered = false;

    }

    // Action to be performed once all the public attributes are set by parent components.
    renderedCallback() {

        // Check to prevent recursive imperative call on render
        if(!this.rendered) {
            // Making imperative apex call to get case list and setting to record variable
            getCaseList({ accountId: this.accountId })
                .then(result => {
                    this.record =  result;
                    this.caseReturned = this.record.length > 0;

                    // Flattening the JSON for display and creating link
                    if(this.record) {
                        let tempRecords = []; 
                        this.record.forEach(rec => {
                            let tempRecord = {};
                            tempRecord = rec;
                            tempRecord.caseUrl = ORGURL+rec.Id;
                            tempRecord.ownerName = rec.Owner.Name;
                            tempRecords.push(tempRecord);
                        });
                        this.record = tempRecords;
                    }
                })
                .catch(error => {
                    this.wireError =  error.body.message;
                })
                // Switching off loader spinner and allow display of data
                .finally(() => {
                    this.rendered = true;
                });
        }
    }
}