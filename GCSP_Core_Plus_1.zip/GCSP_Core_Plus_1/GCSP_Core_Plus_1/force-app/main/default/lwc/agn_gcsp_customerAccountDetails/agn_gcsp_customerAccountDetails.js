import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

import AGN_OAM_Body_Country from '@salesforce/label/c.AGN_OAM_Body_Country';
import AGN_OAM_Body_CustomerType from '@salesforce/label/c.AGN_OAM_Body_CustomerType';
import AGN_OAM_Body_SubType from '@salesforce/label/c.AGN_OAM_Body_SubType';
import AGN_OAM_Body_Surname from '@salesforce/label/c.AGN_OAM_Body_Surname';
import AGN_OAM_Body_Name from '@salesforce/label/c.AGN_OAM_Body_Name';
import AGN_OAM_Body_Title from '@salesforce/label/c.AGN_OAM_Body_Title';


import getHeaderWrapDetails from '@salesforce/apex/AGN_OAMPortalAccountDetailController.getHeaderWrapDetails';

export default class Agn_gcsp_customerAccountDetails extends LightningElement {

    //@api box_img_step1_active = ASSETS + '/assets/Images/Registration/box_img_step1_active.png';
    @api country = '';
    @api language = '';
    @track selectedCountry;
    @track selectedCustomerCategory;
    @track selectedCustomerSubCategory;
    @track picklistCountryOptions;
    @track picklistCustomerTypeOptions;
    @track picklistSubTypeOptions;
    @track customerTypeConfig;
    @track showLoader;
    @track customerSoldToSapData;
    @track customer;
    @track error;

    @api source = null;
    @api sourceOAM = null;
    @api sourceCS = null;

    @api RegistrationStepNo;
    @api caseId;
    @api accountId;


    @api customerType;
    @api customerSubType;
    @track custTypeConfig;
    @track customerGroup;


    label = {
        AGN_OAM_Body_Country,
        AGN_OAM_Body_CustomerType,
        AGN_OAM_Body_SubType,
        AGN_OAM_Body_Surname,
        AGN_OAM_Body_Name,
        AGN_OAM_Body_Title
    };


     connectedCallback() {
        //alert('step1::' + this.sourceCS);
        if (this.sourceOAM && this.sourceOAM === 'oam') {
            this.source = this.sourceOAM;
            this.isOnlineRegistration = true;
        }
        if (this.sourceCS && this.sourceCS === 'cs') {
            this.source = this.sourceCS;          
        }
        console.log('source :::::: ', this.source);       
        this.isCompleted = false;
        this.hidemaindiv = false;      
        this.showLoader = true;
        if( this.source == 'cs'){
            
			//this.getHeaderWrapDetailsCS();
		}
		else{
			this.getHeaderWrapDetails();
		}  
    }
    getHeaderWrapDetails(){
        getHeaderWrapDetails().then(result =>{
            if(result){
                this.customer = result.con;
                this.custTypeConfig = result.customerTypeConfig;
                this.customerSoldToSapData = result.soldToSAPData;
                console.log('result>>>>>'+JSON.stringify(result));
            }
            else{            
                this.showLoader = false;
                this.hidemaindiv = false;              
                this.error = 'Unknown Error';                   
                this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();
            }

        }).catch(error=>{            
            this.showLoader = false;
            this.hidemaindiv = false;
            this.error = error;                   
            this.template.querySelector('c-agn_gcsp_custom-toast').showCustomNotice();

        });
    }

}